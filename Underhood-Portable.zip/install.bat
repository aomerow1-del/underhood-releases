@echo off
setlocal enabledelayedexpansion

set "target=%LocalAppData%\Programs\Underhood"

echo Installing Underhood...
echo Target Directory: !target!

:: Close any running Underhood instances
taskkill /f /im Underhood.exe >nul 2>&1

:: Create directories
if not exist "!target!" mkdir "!target!"
if not exist "!target!\resources" mkdir "!target!\resources"
if not exist "!target!\engine" mkdir "!target!\engine"

:: Copy files from the flat temporary extraction directory into their structured directories
copy /y "Underhood.exe" "!target!\"
copy /y "runner.exe" "!target!\resources\"
copy /y "underhood.vsix" "!target!\resources\"
copy /y "runner.py" "!target!\engine\"
copy /y "analyzer.py" "!target!\engine\"

:: Create Desktop shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=New-Object -ComObject WScript.Shell; $d=[Environment]::GetFolderPath('Desktop'); $lnk=$s.CreateShortcut(\"$d\Underhood.lnk\"); $lnk.TargetPath=\"!target!\Underhood.exe\"; $lnk.WorkingDirectory=\"!target!\"; $lnk.Save()"

:: Create Start Menu shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=New-Object -ComObject WScript.Shell; $p=[Environment]::GetFolderPath('StartMenu')+'\Programs'; if (!(Test-Path \"$p\Underhood\")) { New-Item -ItemType Directory -Path \"$p\Underhood\" }; $lnk=$s.CreateShortcut(\"$p\Underhood\Underhood.lnk\"); $lnk.TargetPath=\"!target!\Underhood.exe\"; $lnk.WorkingDirectory=\"!target!\"; $lnk.Save()"

:: Write registry keys for App Paths (enables launching 'Underhood' directly from Windows Run dialog Win+R)
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\Underhood.exe" /ve /t REG_SZ /d "!target!\Underhood.exe" /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\Underhood.exe" /v "Path" /t REG_SZ /d "!target!" /f >nul 2>&1

:: Write standard Add/Remove Programs registry keys for Current User uninstallation
set "uninstKey=HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Underhood"
reg add "!uninstKey!" /v "DisplayName" /t REG_SZ /d "Underhood" /f >nul 2>&1
reg add "!uninstKey!" /v "UninstallString" /t REG_SZ /d "\"!target!\uninstall.bat\"" /f >nul 2>&1
reg add "!uninstKey!" /v "InstallLocation" /t REG_SZ /d "!target!" /f >nul 2>&1
reg add "!uninstKey!" /v "DisplayVersion" /t REG_SZ /d "0.2.0" /f >nul 2>&1
reg add "!uninstKey!" /v "Publisher" /t REG_SZ /d "Underhood" /f >nul 2>&1
reg add "!uninstKey!" /v "DisplayIcon" /t REG_SZ /d "!target!\Underhood.exe" /f >nul 2>&1

:: Create a self-contained uninstaller batch script inside the installed directory
(
echo @echo off
echo echo Uninstalling Underhood...
echo taskkill /f /im Underhood.exe ^>nul 2^>^&1
echo del /q "%%userprofile%%\Desktop\Underhood.lnk" ^>nul 2^>^&1
echo del /q "%%userprofile%%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Underhood\Underhood.lnk" ^>nul 2^>^&1
echo rd /q "%%userprofile%%\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Underhood" ^>nul 2^>^&1
echo reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\Underhood.exe" /f ^>nul 2^>^&1
echo reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\Underhood" /f ^>nul 2^>^&1
echo reg delete "HKCU\Software\Underhood" /f ^>nul 2^>^&1
echo:: We schedule deletion of target directory via command prompt since we are running uninstall.bat inside it
echo start /b cmd /c "timeout /t 1 /nobreak >nul && rd /s /q \"%%LocalAppData%%\Programs\Underhood\""
echo echo Underhood has been successfully uninstalled.
) > "!target!\uninstall.bat"

echo Done!
exit /b 0
