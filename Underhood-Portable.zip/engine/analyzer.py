"""
engine/analyzer.py — Universal Windows Project Analyzer
========================================================
Detects the project type from manifest files, then checks every tool/SDK
required to BUILD or RUN that project on a Windows machine.

Supported project types:
  Godot, Android, Unity, Flutter/Dart, Rust, .NET/C#, CMake/C++,
  Java/Maven, Java/Gradle, Go, Node.js, Python, PHP, Ruby, Make/C

Usage:
  from engine.analyzer import ProjectAnalyzer
  result = ProjectAnalyzer(folder_path).analyze()
  print(result.to_json())
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import datetime
import tempfile
import urllib.request
import ssl
try:
    import winreg
except ImportError:
    winreg = None
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

IS_MAC = sys.platform == "darwin"

# ── Enrich PATH on Windows ────────────────────────────────────────────────────
# Tauri apps launched via Start Menu/desktop shortcut may not inherit the full
# user PATH.  Enrich it at import-time so every shutil.which() call works.
if sys.platform == "win32":
    import winreg
    def _enrich_windows_path():
        """Read user PATH from registry and add common package-manager dirs."""
        current = os.environ.get("PATH", "")
        parts = [p.strip() for p in current.split(";") if p.strip()]
        seen = {p.lower() for p in parts}

        # User PATH from registry (HKCU\Environment\Path)
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment") as key:
                user_path, _ = winreg.QueryValueEx(key, "Path")
                for p in str(user_path).split(";"):
                    p = p.strip().rstrip("\x00")
                    if p and p.lower() not in seen:
                        parts.append(p)
                        seen.add(p.lower())
        except OSError:
            pass

        # Well-known package manager dirs
        user_profile = os.environ.get("USERPROFILE", "")
        extras = [
            r"C:\ProgramData\chocolatey\bin",
            os.path.join(user_profile, "scoop", "shims"),
            r"C:\ProgramData\scoop\shims",
            r"C:\Windows\System32",
            r"C:\Windows",
            os.path.join(user_profile, "AppData", "Local", "Microsoft", "WindowsApps"),
        ]
        for d in extras:
            if d and d.lower() not in seen:
                parts.append(d)
                seen.add(d.lower())

        os.environ["PATH"] = ";".join(parts)

    _enrich_windows_path()


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class ToolResult:
    name: str
    required: bool
    status: str           # "installed" | "missing" | "outdated" | "unknown"
    version: str = ""
    path: str = ""
    note: str = ""
    install_cmd: str = ""
    install_cmds: dict = field(default_factory=dict)
    install_url: str = ""   # fallback download URL

    def __post_init__(self):
        if not self.install_cmd and self.install_cmds:
            # Pick best available package manager for legacy install_cmd
            for pm in ["brew", "winget", "choco", "scoop", "curl", "py", "python3"]:
                if pm in self.install_cmds and shutil.which(pm):
                    self.install_cmd = self.install_cmds[pm]
                    break


@dataclass
class AnalysisResult:
    project_type: str
    project_name: str
    project_version: str
    project_icon: str         # emoji
    directory: str
    tools: list[ToolResult] = field(default_factory=list)
    can_run: bool = False
    blockers: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    dep_report: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        required_missing = [t for t in self.tools if t.required and t.status == "missing"]
        return {
            "project_type":    self.project_type,
            "project_name":    self.project_name,
            "project_version": self.project_version,
            "project_icon":    self.project_icon,
            "directory":       self.directory,
            "can_run":         len(required_missing) == 0,
            "blockers":        [f"{t.name} is not installed" for t in required_missing],
            "warnings":        self.warnings,
            "notes":           self.notes,
            "tools": [
                {
                    "name":        t.name,
                    "required":    t.required,
                    "status":      t.status,
                    "version":     t.version,
                    "path":        t.path,
                    "note":        t.note,
                    "install_cmds": t.install_cmds,
                    "install_url": t.install_url,
                }
                for t in self.tools
            ],
            # legacy fields so existing frontend code still works
            "returncode": 0,
            "stdout": "",
            "stderr": "",
            "dep_report": self.dep_report,
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


SUBPROCESS_KWARGS = {}
if sys.platform == "win32":
    SUBPROCESS_KWARGS["creationflags"] = 0x08000000

def _get_install_cmds(winget_cmd: str, brew_cmd: str) -> dict:
    cmds = {}
    if IS_MAC:
        if shutil.which("brew"):
            cmds["brew"] = brew_cmd
    else:
        if shutil.which("winget"):
            cmds["winget"] = winget_cmd
        
        # Fallbacks for Windows
        parts = winget_cmd.split()
        if len(parts) >= 3 and parts[0] == "winget" and parts[1] == "install":
            pkg = parts[-1].lower() # e.g. "gradle.gradle"
            pkg_name = pkg.split(".")[-1] # e.g. "gradle"
            
            # Map winget ID tail to choco/scoop ID
            mapping = {
                "androidstudio": "androidstudio",
                "godotengine": "godot",
                "godotengine3": "godot3",
                "8": "dotnet-sdk", # from Microsoft.DotNet.SDK.8
                "buildtools": "visualstudio2022buildtools",
                "fluttersdk": "flutter",
                "dartsdk": "dart-sdk",
                "unityhub": "unity-hub",
                "rustup": "rustup.install",
                "go": "golang",
                "3.2": "ruby", # RubyInstallerTeam.RubyWithDevKit.3.2
                "3": "python3", # Python.Python.3
                "lts": "nodejs-lts", # OpenJS.NodeJS.LTS
            }
            
            choco_pkg = mapping.get(pkg_name, pkg_name)
            
            # OpenJDK mapping
            if "microsoft.openjdk" in pkg:
                choco_pkg = "microsoft-openjdk" + pkg_name
            
            if shutil.which("choco"):
                cmds["choco"] = f"choco install {choco_pkg} -y"
            if shutil.which("scoop"):
                cmds["scoop"] = f"scoop install {choco_pkg}"
            
    return {k: v for k, v in cmds.items() if v}


# ── Low-level tool detection helpers ─────────────────────────────────────────

def _where(cmd: str) -> Optional[str]:
    """Return the full path of `cmd` if found in PATH, else None."""
    path = shutil.which(cmd)
    if path:
        return path
        
    if sys.platform == "win32":
        cmd_no_ext = cmd.lower()
        if cmd_no_ext.endswith('.exe') or cmd_no_ext.endswith('.bat'):
            cmd_no_ext = cmd_no_ext.rsplit('.', 1)[0]
            
        common_paths = {
            "gradle": [
                r"C:\gradle\bin\gradle.bat",
                r"C:\ProgramData\chocolatey\lib\gradle\tools\gradle-*\bin\gradle.bat",
                r"C:\Program Files\Gradle\*\bin\gradle.bat",
                os.path.expanduser(r"~\scoop\apps\gradle\current\bin\gradle.bat")
            ],
            "python": [
                os.path.expanduser(r"~\AppData\Local\Programs\Python\Python*\python.exe"),
                r"C:\Python*\python.exe",
                r"C:\Program Files\Python*\python.exe"
            ],
            "node": [
                r"C:\Program Files\nodejs\node.exe",
                os.path.expanduser(r"~\AppData\Roaming\nvm\v*\node.exe")
            ],
            "java": [
                r"C:\Program Files\Common Files\Oracle\Java\javapath\java.exe",
                r"C:\Program Files\Java\jdk*\bin\java.exe",
                r"C:\Program Files\Eclipse Adoptium\jdk*\bin\java.exe"
            ],
            "cmake": [
                r"C:\Program Files\CMake\bin\cmake.exe"
            ],
            "git": [
                r"C:\Program Files\Git\cmd\git.exe",
                os.path.expanduser(r"~\AppData\Local\Programs\Git\cmd\git.exe")
            ],
            "go": [
                r"C:\Program Files\Go\bin\go.exe"
            ],
            "rustc": [
                os.path.expanduser(r"~\.cargo\bin\rustc.exe")
            ],
            "cargo": [
                os.path.expanduser(r"~\.cargo\bin\cargo.exe")
            ]
        }
        
        if cmd_no_ext in common_paths:
            import glob
            for pattern in common_paths[cmd_no_ext]:
                matches = glob.glob(pattern)
                if matches:
                    return matches[0]
                    
    return None


def _run_version(cmd: list[str]) -> str:
    """Run a command and return its stdout+stderr as a single stripped string."""
    try:
        out = subprocess.check_output(
            cmd, stderr=subprocess.STDOUT,
            timeout=6, **SUBPROCESS_KWARGS
        )
        return out.decode(errors="replace").strip().splitlines()[0]
    except Exception:
        return ""


def _env(name: str) -> str:
    return os.environ.get(name, "").strip()


def _registry_get(hive, key_path: str, value_name: str = "") -> str:
    """Read a Windows registry value. Returns empty string on any error."""
    if not winreg:
        return ""
    try:
        key = winreg.OpenKey(hive, key_path, 0, winreg.KEY_READ)
        val, _ = winreg.QueryValueEx(key, value_name)
        winreg.CloseKey(key)
        return str(val)
    except Exception:
        return ""


def _glob_first(pattern_root: Path, *parts: str) -> Optional[Path]:
    """Find the first path matching a glob under pattern_root."""
    import glob
    pattern = str(pattern_root / Path(*parts))
    matches = glob.glob(pattern, recursive=False)
    return Path(matches[0]) if matches else None


def _check_executable(
    name: str,
    cmd: str,
    version_args: list[str],
    required: bool = True,
    install_cmd: str = "",
    install_cmds: dict = None,
    install_url: str = "",
    note: str = "",
    version_pattern: str = r"[\d]+\.[\d]+[\.\d]*",
) -> ToolResult:
    """
    Generic helper: find `cmd` in PATH, run version_args to get its version,
    return a ToolResult.
    """
    path = _where(cmd)
    if not path:
        return ToolResult(
            name=name, required=required, status="missing",
            install_cmd=install_cmd, install_cmds=install_cmds or {}, install_url=install_url, note=note,
        )
    raw = _run_version([cmd] + version_args)
    m = re.search(version_pattern, raw)
    version = m.group(0) if m else raw[:40] or "found"
    return ToolResult(
        name=name, required=required, status="installed",
        version=version, path=path, note=note,
        install_cmd=install_cmd, install_cmds=install_cmds or {}, install_url=install_url,
    )


# ── Version-pin helpers ──────────────────────────────────────────────────────

def _parse_version_tuple(ver_str: str) -> tuple[int, ...]:
    """
    Convert a version string like '3.10.2', '>=3.10', '^18', '~16.0'
    into a comparable integer tuple. Strips leading operators and 'v' prefix.
    """
    # Strip leading operators / prefixes
    cleaned = re.sub(r'^[^\d]*', '', ver_str.strip())
    # Take just the numeric portion up to the first non-numeric/non-dot char
    m = re.match(r'([\d]+(?:\.[\d]+)*)', cleaned)
    if not m:
        return ()
    parts = m.group(1).split('.')
    try:
        return tuple(int(p) for p in parts)
    except ValueError:
        return ()


def _version_meets(installed_str: str, required_str: str) -> bool:
    """
    Returns True if installed_str >= required_str (ignoring patch if not specified).
    A missing installed version is treated as 'does not meet'.
    """
    if not installed_str or not required_str:
        return True   # can't compare, assume OK
    iv = _parse_version_tuple(installed_str)
    rv = _parse_version_tuple(required_str)
    if not iv or not rv:
        return True
    # Compare only as many digits as required_str specifies
    length = len(rv)
    return iv[:length] >= rv[:length]


def _read_python_version_pin(d: Path) -> str:
    """Returns the required Python version string from project manifests, or ''."""
    # .python-version (pyenv)
    pv = d / '.python-version'
    if pv.exists():
        txt = pv.read_text(encoding='utf-8', errors='ignore').strip()
        m = re.search(r'[\d]+(?:\.[\d]+)*', txt)
        if m:
            return m.group(0)
    # runtime.txt (Heroku / Render)
    rt = d / 'runtime.txt'
    if rt.exists():
        txt = rt.read_text(encoding='utf-8', errors='ignore').strip()
        m = re.search(r'python-([\d]+(?:\.[\d]+)*)', txt, re.IGNORECASE)
        if m:
            return m.group(1)
    # pyproject.toml requires-python
    pp = d / 'pyproject.toml'
    if pp.exists():
        txt = pp.read_text(encoding='utf-8', errors='ignore')
        m = re.search(r'requires-python\s*=\s*["\']([^"\'\']+)["\']', txt)
        if m:
            ver = re.search(r'[\d]+(?:\.[\d]+)*', m.group(1))
            if ver:
                return ver.group(0)
    return ''


def _read_node_version_pin(d: Path) -> str:
    """Returns required Node.js version from .nvmrc / .node-version / package.json engines."""
    for fname in ('.nvmrc', '.node-version'):
        f = d / fname
        if f.exists():
            txt = f.read_text(encoding='utf-8', errors='ignore').strip()
            # e.g. '18', 'v18.12.0', 'lts/hydrogen'
            m = re.search(r'[\d]+(?:\.[\d]+)*', txt)
            if m:
                return m.group(0)
    pkg = d / 'package.json'
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text(encoding='utf-8', errors='ignore'))
            engines_node = data.get('engines', {}).get('node', '')
            m = re.search(r'[\d]+(?:\.[\d]+)*', engines_node)
            if m:
                return m.group(0)
        except Exception:
            pass
    return ''


def _read_go_version_pin(d: Path) -> str:
    """Returns required Go version from go.mod 'go X.Y' directive."""
    gm = d / 'go.mod'
    if gm.exists():
        txt = gm.read_text(encoding='utf-8', errors='ignore')
        m = re.search(r'^go\s+([\d]+\.[\d]+(?:\.[\d]+)?)', txt, re.MULTILINE)
        if m:
            return m.group(1)
    return ''


def _read_rust_channel_pin(d: Path) -> str:
    """Returns required Rust toolchain channel from rust-toolchain.toml."""
    for fname in ('rust-toolchain.toml', 'rust-toolchain'):
        f = d / fname
        if f.exists():
            txt = f.read_text(encoding='utf-8', errors='ignore')
            # rust-toolchain.toml: channel = "1.75.0" or channel = "stable"
            m = re.search(r'channel\s*=\s*["\']([^"\'\']+)["\']', txt)
            if m:
                return m.group(1)
            # Plain rust-toolchain file: just a version or channel name
            stripped = txt.strip()
            if stripped:
                return stripped
    return ''


def _read_java_version_pin(d: Path) -> str:
    """Returns required Java version from pom.xml or build.gradle."""
    pom = d / 'pom.xml'
    if pom.exists():
        txt = pom.read_text(encoding='utf-8', errors='ignore')
        # <java.version>17</java.version> or <maven.compiler.source>11</maven.compiler.source>
        for tag in ('java.version', 'maven.compiler.source', 'maven.compiler.target'):
            m = re.search(rf'<{re.escape(tag)}>([^<]+)</{re.escape(tag)}>', txt)
            if m:
                ver = m.group(1).strip()
                if re.match(r'^[\d]', ver):
                    return ver
    for gradle_file in ('build.gradle', 'build.gradle.kts'):
        bg = d / gradle_file
        if bg.exists():
            txt = bg.read_text(encoding='utf-8', errors='ignore')
            m = re.search(r'(?:sourceCompatibility|javaVersion)\s*[=:]\s*["\']?([\d]+(?:\.[\d]+)?)["\']?', txt)
            if m:
                return m.group(1)
            # Kotlin DSL: JavaVersion.VERSION_17
            m = re.search(r'JavaVersion\.VERSION_(\d+)', txt)
            if m:
                return m.group(1)
    return ''


def _read_ruby_version_pin(d: Path) -> str:
    """Returns required Ruby version from .ruby-version or Gemfile ruby directive."""
    rv = d / '.ruby-version'
    if rv.exists():
        txt = rv.read_text(encoding='utf-8', errors='ignore').strip()
        m = re.search(r'[\d]+(?:\.[\d]+)*', txt)
        if m:
            return m.group(0)
    gf = d / 'Gemfile'
    if gf.exists():
        txt = gf.read_text(encoding='utf-8', errors='ignore')
        m = re.search(r'''^\s*ruby\s+["']([\d .~>=<^]+)["']''', txt, re.MULTILINE)
        if m:
            ver = re.search(r'[\d]+(?:\.[\d]+)*', m.group(1))
            if ver:
                return ver.group(0)
    return ''


def _read_dotnet_version_pin(d: Path) -> str:
    """Returns required .NET SDK version from global.json."""
    gj = d / 'global.json'
    if gj.exists():
        try:
            data = json.loads(gj.read_text(encoding='utf-8', errors='ignore'))
            sdk_ver = data.get('sdk', {}).get('version', '')
            m = re.search(r'[\d]+(?:\.[\d]+)*', sdk_ver)
            if m:
                return m.group(0)
        except Exception:
            pass
    return ''


def _read_php_version_pin(d: Path) -> str:
    """Returns required PHP version from composer.json."""
    cj = d / 'composer.json'
    if cj.exists():
        try:
            data = json.loads(cj.read_text(encoding='utf-8', errors='ignore'))
            php_req = data.get('require', {}).get('php', '')
            m = re.search(r'[\d]+(?:\.[\d]+)*', php_req)
            if m:
                return m.group(0)
        except Exception:
            pass
    return ''


def _read_flutter_version_pin(d: Path) -> str:
    """Returns required Flutter SDK version from pubspec.yaml."""
    py = d / 'pubspec.yaml'
    if py.exists():
        txt = py.read_text(encoding='utf-8', errors='ignore')
        # environment:
        #   flutter: ">=3.10.0"
        m = re.search(r'flutter:\s*["\']?[^\d]*([\d]+(?:\.[\d]+)*)["\']?', txt)
        if m:
            return m.group(1)
    return ''


def _read_cmake_version_pin(d: Path) -> str:
    """Returns required CMake version from CMakeLists.txt."""
    cm = d / 'CMakeLists.txt'
    if cm.exists():
        txt = cm.read_text(encoding='utf-8', errors='ignore')
        m = re.search(r'cmake_minimum_required\s*\(\s*VERSION\s+([\d]+(?:\.[\d]+)*)', txt, re.IGNORECASE)
        if m:
            return m.group(1)
    return ''


def _read_unity_version_pin(d: Path) -> str:
    """Returns required Unity Editor version from ProjectSettings/ProjectVersion.txt."""
    pv = d / 'ProjectSettings' / 'ProjectVersion.txt'
    if pv.exists():
        txt = pv.read_text(encoding='utf-8', errors='ignore')
        m = re.search(r'm_EditorVersion:\s*([^\s]+)', txt)
        if m:
            return m.group(1)
    return ''


def _versioned_python_install(required_ver: str) -> str:
    """Return winget install command for a specific Python version."""
    if not required_ver:
        return 'winget install Python.Python.3'
    # e.g. 3.10 -> Python.Python.3.10
    parts = required_ver.split('.')
    if len(parts) >= 2:
        return f'winget install Python.Python.{parts[0]}.{parts[1]}'
    return f'winget install Python.Python.{parts[0]}'


def _versioned_node_install(required_ver: str) -> str:
    """Return nvm / winget install command for a specific Node version."""
    if not required_ver:
        return 'winget install OpenJS.NodeJS.LTS'
    major = required_ver.split('.')[0]
    return f'nvm install {major}  # or: winget install OpenJS.NodeJS.{major}'


# ── Per-project requirement checkers ─────────────────────────────────────────

def _check_java(required: bool = True, min_major: int = 11) -> ToolResult:
    """Check for JDK (not just JRE). Prefers JAVA_HOME, then PATH."""
    java_home = _env("JAVA_HOME")
    java_cmd = "java"

    if java_home:
        candidate = os.path.join(java_home, "bin", "java" if IS_MAC else "java.exe")
        if os.path.isfile(candidate):
            java_cmd = candidate

    path = _where("java") or (java_cmd if os.path.isfile(java_cmd) else None)
    if not path:
        return ToolResult(
            name=f"Java JDK {min_major}+", required=required, status="missing",
            install_cmds=_get_install_cmds(f"winget install Microsoft.OpenJDK.{min_major}", f"brew install openjdk@{min_major}"),
            install_url="https://adoptium.net/",
            note=f"JDK {min_major}+ required. Set JAVA_HOME after install.",
        )

    raw = _run_version(["java", "-version"])
    m = re.search(r'version "?(\d+)(?:\.(\d+))?', raw)
    if m:
        major = int(m.group(1))
        if major == 1:                   # old 1.8 style
            major = int(m.group(2) or 8)
        version_str = m.group(0).replace('version "', '').strip('"')
        status = "installed" if major >= min_major else "outdated"
        note_str = "" if major >= min_major else f"JDK {min_major}+ needed, found {major}"
    else:
        status = "installed"
        version_str = raw[:40]
        note_str = ""

    return ToolResult(
        name=f"Java JDK {min_major}+", required=required, status=status,
        version=version_str, path=path or java_cmd, note=note_str,
        install_cmds=_get_install_cmds(f"winget install Microsoft.OpenJDK.{min_major}", f"brew install openjdk@{min_major}"),
        install_url="https://adoptium.net/",
    )


def _check_android_sdk() -> ToolResult:
    sdk_root = _env("ANDROID_HOME") or _env("ANDROID_SDK_ROOT")
    # Check Android Studio install for SDK
    if not sdk_root:
        if IS_MAC:
            candidate = os.path.expanduser("~/Library/Android/sdk")
        else:
            local_app = os.environ.get("LOCALAPPDATA", "")
            candidate = os.path.join(local_app, "Android", "Sdk")
        if os.path.isdir(candidate):
            sdk_root = candidate

    if sdk_root and os.path.isdir(sdk_root):
        return ToolResult(
            name="Android SDK", required=True, status="installed",
            path=sdk_root, version="found",
            note="Set ANDROID_HOME if not already set.",
        )
    return ToolResult(
        name="Android SDK", required=True, status="missing",
        install_cmds=_get_install_cmds("winget install Google.AndroidStudio", "brew install --cask android-studio"),
        install_url="https://developer.android.com/studio",
        note="Install Android Studio to get the Android SDK. Set ANDROID_HOME env var.",
    )


def _check_android_studio() -> ToolResult:
    # Check registry for Android Studio on Windows
    reg_val = ""
    if winreg:
        reg_val = _registry_get(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Android Studio",
            "Path"
        )
        if not reg_val:
            reg_val = _registry_get(
                winreg.HKEY_CURRENT_USER,
                r"SOFTWARE\Android Studio",
                "Path"
            )
    # Also check common path
    if IS_MAC:
        studio_path = "/Applications/Android Studio.app"
    else:
        program_files = os.environ.get("PROGRAMFILES", "C:\\Program Files")
        studio_path = os.path.join(program_files, "Android", "Android Studio", "bin", "studio64.exe")

    if reg_val or os.path.exists(studio_path):
        path = reg_val or studio_path
        return ToolResult(
            name="Android Studio", required=False, status="installed",
            path=path, version="found",
        )
    return ToolResult(
        name="Android Studio", required=False, status="missing",
        install_cmds=_get_install_cmds("winget install Google.AndroidStudio", "brew install --cask android-studio"),
        install_url="https://developer.android.com/studio",
        note="Recommended IDE for Android development.",
    )


def _read_godot_version_pin(d: Path) -> str:
    """
    Returns the required Godot version string from project.godot.
    Reads config/features (most reliable in Godot 4) or falls back to
    config_version (5 = Godot 4.x, 4 = Godot 3.x).
    Returns e.g. '4.2', '4', '3' or '' if unknown.
    """
    proj = d / "project.godot"
    if not proj.exists():
        return ""
    try:
        text = proj.read_text(encoding="utf-8", errors="ignore")
        # config/features=PackedStringArray("4.2", ...) — Godot 4
        feat_m = re.search(r'config/features\s*=\s*PackedStringArray\(([^)]+)\)', text)
        if feat_m:
            ver_m = re.search(r'"([\d]+\.[\d]+)"', feat_m.group(1))
            if ver_m:
                return ver_m.group(1)
        # config_version=5 → Godot 4.x, config_version=4 → Godot 3.x
        cv_m = re.search(r'config_version\s*=\s*(\d+)', text)
        if cv_m:
            cv = int(cv_m.group(1))
            return "4" if cv >= 5 else "3"
    except Exception:
        pass
    return ""


def _check_godot(required_version: str = "") -> ToolResult:
    """
    Check for Godot Engine installation.
    required_version: e.g. '4.2', '4', '3' — used to name the tool,
    pick the right winget package, and generate version-specific notes.
    """
    major = required_version.split(".")[0] if required_version else ""
    is_v4 = major == "4" or (required_version == "")
    is_v3 = major == "3"

    tool_name = (
        f"Godot Engine {required_version}" if required_version else "Godot Engine"
    )

    if is_v3:
        winget_id  = "GodotEngine.GodotEngine3"
        dl_url     = "https://godotengine.org/download/3.x/windows/"
        brew_id    = "brew install --cask godot3"
    else:
        # Default to Godot 4 (current stable)
        winget_id  = "GodotEngine.GodotEngine"
        dl_url     = "https://godotengine.org/download/windows/"
        brew_id    = "brew install --cask godot"

    version_note = (
        f"Project requires Godot {required_version}. " if required_version else ""
    )

    # Check PATH first
    for cmd in ("godot", "godot4", "godot3", "Godot"):
        p = _where(cmd)
        if p:
            raw = _run_version([cmd, "--version"])
            m = re.search(r"[\d]+\.[\d]+[\.\d]*", raw)
            installed_ver = m.group(0) if m else raw[:30]
            # Check if major version matches requirement
            if required_version and major and not installed_ver.startswith(major + ".") and installed_ver != major:
                return ToolResult(
                    name=tool_name, required=True, status="outdated",
                    version=installed_ver, path=p,
                    note=f"{version_note}Found Godot {installed_ver} — wrong major version.",
                    install_cmds=_get_install_cmds(f"winget install {winget_id}", brew_id),
                    install_url=dl_url,
                )
            return ToolResult(
                name=tool_name, required=True, status="installed",
                version=installed_ver, path=p,
                note=version_note.rstrip(),
            )

    # Check common install paths
    if IS_MAC:
        candidates = [
            Path("/Applications/Godot.app/Contents/MacOS/Godot"),
            Path("/Applications/Godot.app/Contents/MacOS/godot"),
            Path(os.path.expanduser("~/Applications/Godot.app/Contents/MacOS/Godot")),
        ]
        for c in candidates:
            if c.is_file():
                raw = _run_version([str(c), "--version"])
                m = re.search(r"[\d]+\.[\d]+[\.\d]*", raw)
                installed_ver = m.group(0) if m else "found"
                return ToolResult(
                    name=tool_name, required=True, status="installed",
                    version=installed_ver, path=str(c),
                    note=f"{version_note}Not in PATH — add Godot folder to PATH for convenience.".strip(),
                )
    else:
        parent_dirs = [
            Path(os.environ.get("PROGRAMFILES", "C:\\Program Files")) / "Godot",
            Path(os.environ.get("PROGRAMFILES", "C:\\Program Files")) / "Godot Engine",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Godot",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Godot",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "WinGet" / "Packages",
        ]
        for parent in parent_dirs:
            if not parent.is_dir():
                continue
            try:
                # Direct check
                for f in parent.iterdir():
                    if f.is_file() and 'godot' in f.name.lower() and f.name.endswith('.exe') and 'console' not in f.name.lower():
                        raw = _run_version([str(f), "--version"])
                        m = re.search(r"[\d]+\.[\d]+[\.\d]*", raw)
                        installed_ver = m.group(0) if m else "found"
                        if required_version and major and not installed_ver.startswith(major + ".") and installed_ver != major:
                            continue
                        return ToolResult(
                            name=tool_name, required=True, status="installed",
                            version=installed_ver, path=str(f),
                            note=f"{version_note}Not in PATH — add Godot folder to PATH for convenience.".strip(),
                        )
                # One level deep check (e.g. WinGet subfolders or Programs/Godot subfolders)
                for sub in parent.iterdir():
                    if sub.is_dir():
                        for f in sub.iterdir():
                            if f.is_file() and 'godot' in f.name.lower() and f.name.endswith('.exe') and 'console' not in f.name.lower():
                                raw = _run_version([str(f), "--version"])
                                m = re.search(r"[\d]+\.[\d]+[\.\d]*", raw)
                                installed_ver = m.group(0) if m else "found"
                                if required_version and major and not installed_ver.startswith(major + ".") and installed_ver != major:
                                    continue
                                return ToolResult(
                                    name=tool_name, required=True, status="installed",
                                    version=installed_ver, path=str(f),
                                    note=f"{version_note}Not in PATH — add Godot folder to PATH for convenience.".strip(),
                                )
            except Exception:
                pass

    return ToolResult(
        name=tool_name, required=True, status="missing",
        install_cmds=_get_install_cmds(f"winget install {winget_id}", brew_id),
        install_url=dl_url,
        note=f"{version_note}Download Godot {required_version or '4'} and add it to your PATH.",
    )


def _check_dotnet() -> ToolResult:
    return _check_executable(
        name=".NET SDK", cmd="dotnet", version_args=["--version"],
        install_cmds=_get_install_cmds("winget install Microsoft.DotNet.SDK.8", "brew install --cask dotnet-sdk"),
        install_url="https://dotnet.microsoft.com/download",
    )


def _check_msbuild() -> ToolResult:
    if IS_MAC:
        # On macOS, msbuild is not installed as a standalone tool, dotnet build is used.
        dotnet = _where("dotnet")
        if dotnet:
            return ToolResult(
                name="MSBuild", required=False, status="installed",
                path=dotnet, version="found",
                note="On macOS, .NET SDK uses dotnet build directly.",
            )
        return ToolResult(
            name="MSBuild", required=False, status="missing",
            install_cmd="brew install --cask dotnet-sdk",
            install_url="https://dotnet.microsoft.com/download",
            note="Install .NET SDK to get build support.",
        )

    # Check vswhere or common VS path
    vswhere = r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"
    if os.path.isfile(vswhere):
        try:
            out = subprocess.check_output(
                [vswhere, "-latest", "-requires", "Microsoft.Component.MSBuild",
                 "-find", r"MSBuild\**\Bin\MSBuild.exe"],
                stderr=subprocess.DEVNULL, timeout=6,
                **SUBPROCESS_KWARGS
            ).decode().strip()
            if out and os.path.isfile(out.splitlines()[0]):
                return ToolResult(
                    name="MSBuild (Visual Studio)", required=False,
                    status="installed", path=out.splitlines()[0], version="found",
                )
        except Exception:
            pass

    msbuild = _where("msbuild")
    if msbuild:
        return ToolResult(name="MSBuild (Visual Studio)", required=False,
                          status="installed", path=msbuild, version="found")

    return ToolResult(
        name="MSBuild (Visual Studio)", required=False, status="missing",
        install_cmd="winget install Microsoft.VisualStudio.2022.BuildTools",
        install_url="https://visualstudio.microsoft.com/downloads/",
        note="Optional but recommended for full .NET/C# build support.",
    )


def _check_cmake() -> ToolResult:
    return _check_executable(
        name="CMake", cmd="cmake", version_args=["--version"],
        install_cmds=_get_install_cmds("winget install Kitware.CMake", "brew install cmake"),
        install_url="https://cmake.org/download/",
    )


def _check_cpp_compiler() -> ToolResult:
    # Check for MSVC cl.exe
    cl = _where("cl")
    if cl:
        return ToolResult(name="C++ Compiler (MSVC cl.exe)", required=True,
                          status="installed", path=cl, version="found")
    # Check for MinGW g++
    gpp = _where("g++")
    if gpp:
        raw = _run_version(["g++", "--version"])
        m = re.search(r"[\d]+\.[\d]+[\.\d]*", raw)
        return ToolResult(name="C++ Compiler (g++)", required=True,
                          status="installed", path=gpp,
                          version=m.group(0) if m else "found")
    # Check for clang
    clang = _where("clang++")
    if clang:
        raw = _run_version(["clang++", "--version"])
        m = re.search(r"[\d]+\.[\d]+[\.\d]*", raw)
        return ToolResult(name="C++ Compiler (clang++)", required=True,
                          status="installed", path=clang,
                          version=m.group(0) if m else "found")

    return ToolResult(
        name="C++ Compiler", required=True, status="missing",
        install_cmds=_get_install_cmds("winget install Microsoft.VisualStudio.2022.BuildTools", "xcode-select --install"),
        install_url="https://developer.apple.com/xcode/" if IS_MAC else "https://visualstudio.microsoft.com/downloads/",
        note="Install Xcode Command Line Tools by running: xcode-select --install" if IS_MAC else "Install Visual Studio Build Tools (MSVC) or MinGW-w64.",
    )


def _check_ninja() -> ToolResult:
    return _check_executable(
        name="Ninja Build", cmd="ninja", version_args=["--version"],
        required=False,
        install_cmds=_get_install_cmds("winget install Ninja-build.Ninja", "brew install ninja"),
        install_url="https://ninja-build.org/",
        note="Optional but faster than Make for CMake builds.",
    )


def _check_flutter() -> ToolResult:
    flutter_root = _env("FLUTTER_ROOT")
    flutter_cmd = "flutter"
    if flutter_root:
        candidate = os.path.join(flutter_root, "bin", "flutter" if IS_MAC else "flutter.bat")
        if os.path.isfile(candidate):
            flutter_cmd = candidate

    p = _where("flutter")
    if not p and not os.path.isfile(flutter_cmd):
        return ToolResult(
            name="Flutter SDK", required=True, status="missing",
            install_cmds=_get_install_cmds("winget install Google.FlutterSDK", "brew install --cask flutter"),
            install_url="https://flutter.dev/docs/get-started/install/macos" if IS_MAC else "https://flutter.dev/docs/get-started/install/windows",
            note="Set FLUTTER_ROOT and add flutter/bin to PATH after install.",
        )
    raw = _run_version(["flutter", "--version"])
    m = re.search(r"Flutter ([\d]+\.[\d]+[\.\d]*)", raw)
    return ToolResult(
        name="Flutter SDK", required=True, status="installed",
        version=m.group(1) if m else "found",
        path=p or flutter_cmd,
    )


def _check_dart() -> ToolResult:
    return _check_executable(
        name="Dart SDK", cmd="dart", version_args=["--version"],
        required=False,
        install_cmds=_get_install_cmds("winget install Google.DartSDK", "brew install dart"),
        install_url="https://dart.dev/get-dart",
        note="Usually bundled with Flutter.",
    )


def _check_unity_hub() -> ToolResult:
    if IS_MAC:
        hub_path = "/Applications/Unity Hub.app"
        if os.path.isdir(hub_path):
            return ToolResult(
                name="Unity Hub", required=True, status="installed",
                path=hub_path,
            )
    else:
        hub_path = r"C:\Program Files\Unity Hub\Unity Hub.exe"
        alt_path  = os.path.join(
            os.environ.get("PROGRAMFILES", "C:\\Program Files"),
            "Unity Hub", "Unity Hub.exe"
        )
        if os.path.isfile(hub_path) or os.path.isfile(alt_path):
            return ToolResult(
                name="Unity Hub", required=True, status="installed",
                path=hub_path if os.path.isfile(hub_path) else alt_path,
            )
    return ToolResult(
        name="Unity Hub", required=True, status="missing",
        install_cmds=_get_install_cmds("winget install Unity.UnityHub", "brew install --cask unity-hub"),
        install_url="https://unity.com/download",
        note="Unity Hub manages Unity Editor installations.",
    )


def _check_unity_editor() -> ToolResult:
    base = Path("/Applications/Unity/Hub/Editor") if IS_MAC else Path(r"C:\Program Files\Unity\Hub\Editor")
    if base.is_dir():
        versions = [d for d in base.iterdir() if d.is_dir()]
        if versions:
            latest = sorted(versions)[-1]
            return ToolResult(
                name="Unity Editor", required=True, status="installed",
                version=latest.name, path=str(latest),
            )
    return ToolResult(
        name="Unity Editor", required=True, status="missing",
        install_cmd="",
        install_url="https://unity.com/download",
        note="Install Unity Editor via Unity Hub.",
    )


# ── Project type detector ─────────────────────────────────────────────────────

DETECTION_RULES = [
    # (priority, marker_file_or_dir, project_type)
    # Higher priority = checked first
    (100, "project.godot",          "Godot"),
    (100, "ProjectSettings",        "Unity"),        # dir
    (100, "pubspec.yaml",           "Flutter"),
    (100, "Cargo.toml",             "Rust"),
    (100, "go.mod",                 "Go"),
    (100, "pom.xml",                "Java/Maven"),
    ( 90, "AndroidManifest.xml",    "Android"),
    ( 90, "composer.json",          "PHP"),
    ( 90, "Gemfile",                "Ruby"),
    ( 80, "CMakeLists.txt",         "C++/CMake"),
    ( 80, "Makefile",               "C/C++/Make"),
    ( 70, "requirements.txt",       "Python"),
    ( 70, "pyproject.toml",         "Python"),
    ( 70, "setup.py",               "Python"),
    ( 60, "package.json",           "Node.js"),
    ( 50, "*.sln",                  "dotnet_glob"),  # handled specially
    ( 50, "*.csproj",               "dotnet_glob"),
]


def is_local_module(directory: str, pkg_name: str, runtime: str) -> bool:
    """Returns True if pkg_name corresponds to a local file/folder inside the project workspace."""
    if not pkg_name or not directory:
        return False
    d = Path(directory)
    if not d.is_dir():
        return False
    clean = pkg_name.strip().split('/')[0].split('.')[0]
    if runtime == 'python':
        candidates = [
            d / f"{clean}.py",
            d / clean / "__init__.py",
            d / "src" / f"{clean}.py",
            d / "src" / clean / "__init__.py",
        ]
        return any(c.exists() for c in candidates)
    elif runtime in ('node', 'typescript'):
        candidates = [
            d / f"{clean}.js",
            d / f"{clean}.ts",
            d / f"{clean}.jsx",
            d / f"{clean}.tsx",
            d / clean / "index.js",
            d / clean / "index.ts",
            d / "src" / f"{clean}.js",
            d / "src" / f"{clean}.ts",
        ]
        return any(c.exists() for c in candidates)
    elif runtime == 'lua':
        candidates = [
            d / f"{clean}.lua",
            d / clean / "init.lua",
        ]
        return any(c.exists() for c in candidates)
    elif runtime == 'ruby':
        candidates = [
            d / f"{clean}.rb",
            d / "lib" / f"{clean}.rb",
        ]
        return any(c.exists() for c in candidates)
    elif runtime == 'powershell':
        candidates = [
            d / f"{clean}.ps1",
            d / f"{clean}.psm1",
            d / f"{clean}.psd1",
        ]
        return any(c.exists() for c in candidates)
    return False


def _check_project_type_for_path(d: Path) -> Optional[tuple[str, str, str]]:
    """Runs type detection on a single directory path. Returns (type, name, version) if matched."""
    if not d.is_dir():
        return None

    # Android: build.gradle + (java dir OR AndroidManifest deep scan)
    has_android_manifest = (d / "AndroidManifest.xml").exists()
    has_android_dir = (d / "app").is_dir() and ((d / "app" / "build.gradle").exists() or (d / "app" / "build.gradle.kts").exists())
    if has_android_manifest or has_android_dir:
        name, version = _parse_android_info(d)
        return "Android", name, version

    # Godot
    if (d / "project.godot").exists():
        name, version = _parse_godot_info(d)
        return "Godot", name, version

    # Unity
    if (d / "ProjectSettings").is_dir() and (d / "Assets").is_dir():
        name, version = _parse_unity_info(d)
        return "Unity", name, version

    # Flutter / Dart
    if (d / "pubspec.yaml").exists():
        name, version = _parse_pubspec_info(d)
        try:
            pubspec_content = (d / "pubspec.yaml").read_text(encoding="utf-8", errors="ignore")
            if "sdk: flutter" in pubspec_content:
                return "Flutter", name, version
            else:
                return "Dart", name, version
        except Exception:
            return "Flutter", name, version

    # Rust
    if (d / "Cargo.toml").exists():
        name, version = _parse_toml_info(d / "Cargo.toml", "name", "version")
        return "Rust", name, version

    # Go
    if (d / "go.mod").exists():
        name, version = _parse_go_mod(d)
        return "Go", name, version

    # Java Maven
    if (d / "pom.xml").exists():
        name = _parse_xml_tag(d / "pom.xml", "artifactId") or d.name
        version = _parse_xml_tag(d / "pom.xml", "version") or ""
        return "Java/Maven", name, version

    # Java Gradle
    if (d / "build.gradle").exists() or (d / "build.gradle.kts").exists():
        return "Java/Gradle", d.name, ""

    # .NET (look for .sln or .csproj)
    sln_files = list(d.glob("*.sln"))
    csproj_files = list(d.glob("*.csproj")) + list(d.glob("**/*.csproj"))
    if sln_files or csproj_files:
        target = sln_files[0] if sln_files else csproj_files[0]
        return ".NET/C#", target.stem, ""

    # C++ CMake
    if (d / "CMakeLists.txt").exists():
        name = _parse_cmake_name(d) or d.name
        return "C++/CMake", name, ""

    # Makefile
    if (d / "Makefile").exists() or (d / "makefile").exists():
        return "C/C++/Make", d.name, ""

    # PHP
    if (d / "composer.json").exists():
        name, version = _parse_json_name_version(d / "composer.json")
        return "PHP", name, version

    # Ruby
    if (d / "Gemfile").exists():
        return "Ruby", d.name, ""

    # TypeScript / Bun / Deno
    if (d / "tsconfig.json").exists() or (d / "deno.json").exists() or (d / "deno.jsonc").exists() or (d / "bunfig.toml").exists():
        name, version = _parse_json_name_version(d / "package.json") if (d / "package.json").exists() else (d.name, "")
        return "TypeScript", name, version

    # Node.js
    if (d / "package.json").exists():
        name, version = _parse_json_name_version(d / "package.json")
        return "Node.js", name, version

    # Python
    for marker in ("requirements.txt", "pyproject.toml", "setup.py"):
        if (d / marker).exists():
            return "Python", d.name, ""

    # Lua
    try:
        if any(f.name.endswith('.rockspec') for f in d.iterdir() if f.is_file()):
            return "Lua", d.name, ""
        if any(f.name.endswith('.lua') for f in d.iterdir() if f.is_file()):
            return "Lua", d.name, ""
    except Exception:
        pass

    # Swift (iOS / macOS / Swift Package Manager)
    if (d / "Package.swift").exists():
        name, version = _parse_swift_package(d)
        return "Swift", name, version
    try:
        if any(f.name.endswith('.xcodeproj') for f in d.iterdir() if f.is_dir()):
            return "Swift/Xcode", d.name, ""
        if any(f.name.endswith('.xcworkspace') for f in d.iterdir() if f.is_dir()):
            return "Swift/Xcode", d.name, ""
    except Exception:
        pass

    # Unreal Engine
    try:
        if any(f.name.endswith('.uproject') for f in d.iterdir() if f.is_file()):
            uproject = next(f for f in d.iterdir() if f.name.endswith('.uproject'))
            return "Unreal Engine", uproject.stem, ""
    except Exception:
        pass

    # Zig
    if (d / "build.zig").exists():
        return "Zig", d.name, ""

    # Elixir
    if (d / "mix.exs").exists():
        return "Elixir", d.name, ""

    # Scala
    if (d / "build.sbt").exists():
        return "Scala", d.name, ""

    # PowerShell
    try:
        if any(f.name.endswith(('.psd1', '.psm1')) for f in d.iterdir() if f.is_file()):
            return "PowerShell", d.name, ""
        if any(f.name.endswith('.ps1') for f in d.iterdir() if f.is_file()):
            return "PowerShell", d.name, ""
    except Exception:
        pass

    return None


def _detect_project_type(directory: str) -> tuple[str, str, str, str]:
    """
    Returns (project_type, project_name, project_version, project_dir_path).
    Scans root directory first, then direct subdirectories.
    """
    root_dir = Path(directory)

    # 1. Check top-level folder first
    matched = _check_project_type_for_path(root_dir)
    if matched:
        return matched[0], matched[1], matched[2], str(root_dir)

    # 2. Check direct subdirectories (excluding hidden and standard package/build folders)
    try:
        for entry in root_dir.iterdir():
            if entry.is_dir() and not entry.name.startswith('.') and entry.name not in ('node_modules', 'venv', '.venv', 'env', 'dist', 'build'):
                matched = _check_project_type_for_path(entry)
                if matched:
                    return matched[0], matched[1], matched[2], str(entry)
    except Exception:
        pass

    return "Unknown", root_dir.name, "", str(root_dir)


# ── Project-file parsers ──────────────────────────────────────────────────────

def _parse_godot_info(d: Path) -> tuple[str, str]:
    try:
        text = (d / "project.godot").read_text(encoding="utf-8", errors="ignore")
        name_m = re.search(r'config/name\s*=\s*"([^"]+)"', text)
        ver_m  = re.search(r'config_version\s*=\s*(\d+)', text)
        name = name_m.group(1) if name_m else d.name
        ver  = f"v{ver_m.group(1)}" if ver_m else ""
        return name, ver
    except Exception:
        return d.name, ""


def _parse_unity_info(d: Path) -> tuple[str, str]:
    try:
        ver_file = d / "ProjectSettings" / "ProjectVersion.txt"
        if ver_file.exists():
            text = ver_file.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"m_EditorVersion:\s*([\d\.a-z]+)", text)
            ver = m.group(1) if m else ""
        else:
            ver = ""
        return d.name, ver
    except Exception:
        return d.name, ""


def _parse_android_info(d: Path) -> tuple[str, str]:
    try:
        manifest = d / "AndroidManifest.xml"
        if not manifest.exists():
            manifest = d / "app" / "src" / "main" / "AndroidManifest.xml"
        if manifest.exists():
            text = manifest.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r'package="([^"]+)"', text)
            name = m.group(1).split(".")[-1].capitalize() if m else d.name
            return name, ""
    except Exception:
        pass
    return d.name, ""


def _parse_pubspec_info(d: Path) -> tuple[str, str]:
    try:
        text = (d / "pubspec.yaml").read_text(encoding="utf-8", errors="ignore")
        name_m = re.search(r"^name:\s*(.+)$", text, re.MULTILINE)
        ver_m  = re.search(r"^version:\s*(.+)$", text, re.MULTILINE)
        return (name_m.group(1).strip() if name_m else d.name,
                ver_m.group(1).strip() if ver_m else "")
    except Exception:
        return d.name, ""


def _parse_toml_info(path: Path, name_key: str, ver_key: str) -> tuple[str, str]:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        name_m = re.search(rf'^{name_key}\s*=\s*"([^"]+)"', text, re.MULTILINE)
        ver_m  = re.search(rf'^{ver_key}\s*=\s*"([^"]+)"', text, re.MULTILINE)
        return (name_m.group(1) if name_m else path.parent.name,
                ver_m.group(1) if ver_m else "")
    except Exception:
        return path.parent.name, ""


def _parse_go_mod(d: Path) -> tuple[str, str]:
    try:
        text = (d / "go.mod").read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"^module\s+(.+)$", text, re.MULTILINE)
        name = m.group(1).strip().split("/")[-1] if m else d.name
        return name, ""
    except Exception:
        return d.name, ""


def _parse_xml_tag(path: Path, tag: str) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
        m = re.search(rf"<{tag}>([^<]+)</{tag}>", text)
        return m.group(1).strip() if m else ""
    except Exception:
        return ""


def _parse_cmake_name(d: Path) -> str:
    try:
        text = (d / "CMakeLists.txt").read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"project\s*\(\s*([^\s)]+)", text, re.IGNORECASE)
        return m.group(1) if m else ""
    except Exception:
        return ""


def _parse_json_name_version(path: Path) -> tuple[str, str]:
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        return data.get("name", path.parent.name), data.get("version", "")
    except Exception:
        return path.parent.name, ""


def _parse_swift_package(d: Path) -> tuple[str, str]:
    """Parse name and version from Package.swift."""
    try:
        text = (d / "Package.swift").read_text(encoding="utf-8", errors="ignore")
        m = re.search(r'name:\s*"([^"]+)"', text)
        name = m.group(1) if m else d.name
        return name, ""
    except Exception:
        return d.name, ""


# ── Project icons ─────────────────────────────────────────────────────────────

PROJECT_ICONS = {
    "Godot":          "[GAME]",
    "Unity":          "[UNITY]",
    "Android":        "[ANDROID]",
    "Flutter":        "[FLUTTER]",
    "Rust":           "[RUST]",
    "Go":             "[GO]",
    "Java/Maven":     "[JAVA]",
    "Java/Gradle":    "[JAVA]",
    ".NET/C#":        "[.NET]",
    "C++/CMake":      "[C++]",
    "C/C++/Make":     "[C/C++]",
    "PHP":            "[PHP]",
    "Ruby":           "[RUBY]",
    "TypeScript":     "[TS]",
    "Node.js":        "[NODE]",
    "Python":         "[PYTHON]",
    "Lua":            "[LUA]",
    "Swift":          "[SWIFT]",
    "Swift/Xcode":    "[SWIFT]",
    "Unreal Engine":  "[UNREAL]",
    "Zig":            "[ZIG]",
    "Elixir":         "[ELIXIR]",
    "Dart":           "[DART]",
    "Scala":          "[SCALA]",
    "PowerShell":     "[PS]",
    "Unknown":        "[?]",
}


# ── Requirements matrix ───────────────────────────────────────────────────────

def _get_tools_for(project_type: str, directory: str) -> list[ToolResult]:
    d = Path(directory)
    tools = []

    if project_type == "Godot":
        required_godot = _read_godot_version_pin(Path(directory))
        tools.append(_check_godot(required_version=required_godot))

    elif project_type == "Unity":
        tools.append(_check_unity_hub())
        required_unity = _read_unity_version_pin(Path(directory))
        unity_editor = _check_unity_editor()
        if required_unity and unity_editor.status == "installed":
            if unity_editor.version != required_unity and not unity_editor.version.startswith(required_unity):
                unity_editor.status = "outdated"
                unity_editor.note = f"Requires Unity {required_unity}, found {unity_editor.version}. Install via Unity Hub."
        elif required_unity:
            unity_editor.note = f"Project requires Unity {required_unity}. Install via Unity Hub."
        tools.append(unity_editor)
        # Unity Android builds also need JDK + Android SDK
        tools.append(ToolResult(
            name="Note: Android target needs JDK + Android SDK",
            required=False, status="installed" if True else "missing",
            note="If building for Android, also install JDK 11+ and Android SDK.",
        ))

    elif project_type == "Android":
        tools.append(_check_java(required=True, min_major=11))
        tools.append(_check_android_sdk())
        tools.append(_check_android_studio())
        # Check for gradle wrapper
        gradlew = d / "gradlew" if IS_MAC else d / "gradlew.bat"
        if gradlew.exists():
            tools.append(ToolResult(
                name="Gradle Wrapper (gradlew)", required=True,
                status="installed", path=str(gradlew),
                note="Use ./gradlew assembleDebug to build.",
            ))
        else:
            tools.append(_check_executable(
                name="Gradle", cmd="gradle", version_args=["--version"],
                required=True,
                install_cmds={"choco": "choco install gradle -y", "scoop": "scoop install gradle", "brew": "brew install gradle"},
                install_url="https://gradle.org/install/",
            ))
        tools.append(_check_executable(
            name="ADB (Android Debug Bridge)", cmd="adb", version_args=["version"],
            required=False,
            install_cmd="",
            install_url="https://developer.android.com/tools/adb",
            note="Included with Android SDK platform-tools.",
        ))

    elif project_type == "Flutter":
        required_flutter = _read_flutter_version_pin(Path(directory))
        flutter_tool = _check_flutter()
        if required_flutter and flutter_tool.status == "installed":
            if not _version_meets(flutter_tool.version, required_flutter):
                flutter_tool.status = "outdated"
                flutter_tool.note = f"Requires Flutter {required_flutter}, found {flutter_tool.version}"
        elif required_flutter:
            flutter_tool.note = f"Project requires Flutter {required_flutter}"
        tools.append(flutter_tool)
        tools.append(_check_dart())
        tools.append(_check_java(required=False, min_major=11))
        tools.append(_check_android_sdk())

    elif project_type == "Rust":
        cargo_tool = _check_executable(
            name="Rust (cargo)", cmd="cargo", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install Rustlang.Rustup", "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"),
            install_url="https://rustup.rs/",
        )
        required_rust = _read_rust_channel_pin(Path(directory))
        if required_rust:
            # channel can be 'stable', 'nightly', '1.75.0' etc.
            is_version = re.match(r'^[\d]', required_rust)
            if is_version and cargo_tool.status == "installed":
                if not _version_meets(cargo_tool.version, required_rust):
                    cargo_tool.status = "outdated"
                    cargo_tool.note = f"Requires Rust {required_rust}, found {cargo_tool.version}"
                    if IS_MAC:
                        cargo_tool.install_cmd = f"rustup install {required_rust} && rustup default {required_rust}"
                    else:
                        cargo_tool.install_cmd = f"cmd /c \"rustup install {required_rust} && rustup default {required_rust}\""
            elif cargo_tool.status == "installed":
                cargo_tool.note = f"Project pins channel: {required_rust}  (run: rustup default {required_rust})"
        tools.append(cargo_tool)
        tools.append(_check_executable(
            name="Rust compiler (rustc)", cmd="rustc", version_args=["--version"],
            required=False,
            install_cmds=_get_install_cmds("winget install Rustlang.Rustup", "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh"),
            install_url="https://rustup.rs/",
            note="Installed automatically with rustup.",
        ))
        tools.append(_check_cpp_compiler())

    elif project_type == "Go":
        go_tool = _check_executable(
            name="Go", cmd="go", version_args=["version"],
            install_cmds=_get_install_cmds("winget install GoLang.Go", "brew install go"),
            install_url="https://go.dev/dl/",
        )
        required_go = _read_go_version_pin(Path(directory))
        if required_go and go_tool.status == "installed":
            if not _version_meets(go_tool.version, required_go):
                go_tool.status = "outdated"
                go_tool.note = f"Requires Go {required_go}, found {go_tool.version}"
                go_tool.install_cmds = _get_install_cmds(
                    f"winget install GoLang.Go  # then install Go {required_go} from go.dev",
                    f"brew install go  # then install Go {required_go} from go.dev"
                )
        elif required_go and go_tool.status == "missing":
            go_tool.note = f"Project requires Go {required_go}"
        tools.append(go_tool)

    elif project_type == "Java/Maven":
        pinned_java = _read_java_version_pin(Path(directory))
        min_java = int(pinned_java.split('.')[0]) if pinned_java and pinned_java.split('.')[0].isdigit() else 11
        java_tool = _check_java(required=True, min_major=min_java)
        if pinned_java and java_tool.status == "installed":
            if not _version_meets(java_tool.version, pinned_java):
                java_tool.status = "outdated"
                java_tool.note = f"Requires Java {pinned_java}, found {java_tool.version}"
                java_tool.install_cmds = _get_install_cmds(
                    f"winget install Microsoft.OpenJDK.{min_java}",
                    f"brew install openjdk@{min_java}"
                )
        elif pinned_java:
            java_tool.note = f"Project requires Java {pinned_java}"
        tools.append(java_tool)
        tools.append(_check_executable(
            name="Maven (mvn)", cmd="mvn", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install Apache.Maven", "brew install maven"),
            install_url="https://maven.apache.org/download.cgi",
        ))

    elif project_type == "Java/Gradle":
        pinned_java = _read_java_version_pin(Path(directory))
        min_java = int(pinned_java.split('.')[0]) if pinned_java and pinned_java.split('.')[0].isdigit() else 11
        java_tool = _check_java(required=True, min_major=min_java)
        if pinned_java and java_tool.status == "installed":
            if not _version_meets(java_tool.version, pinned_java):
                java_tool.status = "outdated"
                java_tool.note = f"Requires Java {pinned_java}, found {java_tool.version}"
                java_tool.install_cmds = _get_install_cmds(
                    f"winget install Microsoft.OpenJDK.{min_java}",
                    f"brew install openjdk@{min_java}"
                )
        elif pinned_java:
            java_tool.note = f"Project requires Java {pinned_java}"
        tools.append(java_tool)
        tools.append(_check_executable(
            name="Gradle", cmd="gradle", version_args=["--version"],
            install_cmds={"choco": "choco install gradle -y", "scoop": "scoop install gradle", "brew": "brew install gradle"},
            install_url="https://gradle.org/install/",
        ))

    elif project_type == ".NET/C#":
        required_dotnet = _read_dotnet_version_pin(Path(directory))
        dotnet_tool = _check_dotnet()
        if required_dotnet and dotnet_tool.status == "installed":
            if not _version_meets(dotnet_tool.version, required_dotnet):
                dotnet_tool.status = "outdated"
                dotnet_tool.note = f"Requires .NET SDK {required_dotnet}, found {dotnet_tool.version}"
                major = required_dotnet.split(".")[0] if "." in required_dotnet else required_dotnet
                dotnet_tool.install_cmds = _get_install_cmds(f"winget install Microsoft.DotNet.SDK.{major}", "brew install --cask dotnet-sdk")
        elif required_dotnet:
            dotnet_tool.note = f"Project requires .NET SDK {required_dotnet}"
        tools.append(dotnet_tool)
        tools.append(_check_msbuild())

    elif project_type == "C++/CMake":
        required_cmake = _read_cmake_version_pin(Path(directory))
        cmake_tool = _check_cmake()
        if required_cmake and cmake_tool.status == "installed":
            if not _version_meets(cmake_tool.version, required_cmake):
                cmake_tool.status = "outdated"
                cmake_tool.note = f"Requires CMake {required_cmake}, found {cmake_tool.version}"
        elif required_cmake:
            cmake_tool.note = f"Project requires CMake {required_cmake}"
        tools.append(cmake_tool)
        tools.append(_check_cpp_compiler())
        tools.append(_check_ninja())

    elif project_type == "C/C++/Make":
        tools.append(_check_cpp_compiler())
        # Check for make
        make = _where("make") or _where("mingw32-make")
        if make:
            tools.append(ToolResult(
                name="Make", required=True, status="installed", path=make,
            ))
        else:
            tools.append(ToolResult(
                name="Make", required=True, status="missing",
                install_cmds=_get_install_cmds("winget install GnuWin32.Make", "xcode-select --install"),
                install_url="https://www.gnu.org/software/make/",
            ))

    elif project_type == "PHP":
        required_php = _read_php_version_pin(Path(directory))
        php_tool = _check_executable(
            name="PHP", cmd="php", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install PHP.PHP", "brew install php"),
            install_url="https://www.php.net/downloads",
        )
        if required_php and php_tool.status == "installed":
            if not _version_meets(php_tool.version, required_php):
                php_tool.status = "outdated"
                php_tool.note = f"Requires PHP {required_php}, found {php_tool.version}"
        elif required_php:
            php_tool.note = f"Project requires PHP {required_php}"
        tools.append(php_tool)
        tools.append(_check_executable(
            name="Composer", cmd="composer", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install Composer.Composer", "brew install composer"),
            install_url="https://getcomposer.org/download/",
        ))

    elif project_type == "Ruby":
        ruby_tool = _check_executable(
            name="Ruby", cmd="ruby", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install RubyInstallerTeam.RubyWithDevKit.3.2", "brew install ruby"),
            install_url="https://rubyinstaller.org/",
        )
        required_ruby = _read_ruby_version_pin(Path(directory))
        if required_ruby and ruby_tool.status == "installed":
            if not _version_meets(ruby_tool.version, required_ruby):
                ruby_tool.status = "outdated"
                ruby_tool.note = f"Requires Ruby {required_ruby}, found {ruby_tool.version}"
                parts = required_ruby.split('.')
                if len(parts) >= 2:
                    ruby_tool.install_cmds = _get_install_cmds(
                        f"winget install RubyInstallerTeam.RubyWithDevKit.{parts[0]}.{parts[1]}",
                        f"brew install ruby@{parts[0]}.{parts[1]}"
                    )
        elif required_ruby:
            ruby_tool.note = f"Project requires Ruby {required_ruby}"
        tools.append(ruby_tool)
        tools.append(_check_executable(
            name="Bundler (gem)", cmd="bundle", version_args=["--version"],
            required=False,
            install_cmd="gem install bundler",
            install_url="https://bundler.io/",
        ))

    elif project_type == "TypeScript":
        tools.append(_check_executable(
            name="Node.js", cmd="node", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install OpenJS.NodeJS.LTS", "brew install node"),
            install_url="https://nodejs.org/",
        ))
        tools.append(_check_executable(
            name="npm", cmd="npm", version_args=["--version"], required=False,
            install_cmds=_get_install_cmds("winget install OpenJS.NodeJS.LTS", "brew install node"),
            install_url="https://nodejs.org/",
        ))
        tools.append(_check_executable(
            name="TypeScript Compiler (tsc)", cmd="tsc", version_args=["--version"], required=False,
            install_cmd="npm install -g typescript", install_url="https://www.typescriptlang.org/",
        ))
        tools.append(_check_executable(
            name="tsx (TypeScript Execute)", cmd="tsx", version_args=["--version"], required=False,
            install_cmd="npm install -g tsx", install_url="https://github.com/privatenumber/tsx",
        ))
        tools.append(_check_executable(
            name="Bun", cmd="bun", version_args=["--version"], required=False,
            install_cmds=_get_install_cmds("winget install Oven-sh.Bun", "brew install oven-sh/bun/bun"),
            install_url="https://bun.sh/",
        ))
        tools.append(_check_executable(
            name="Deno", cmd="deno", version_args=["--version"], required=False,
            install_cmds=_get_install_cmds("winget install DenoLand.Deno", "brew install deno"),
            install_url="https://deno.land/",
        ))

    elif project_type == "PowerShell":
        tools.append(_check_executable(
            name="PowerShell", cmd="pwsh" if _where("pwsh") else "powershell",
            version_args=["--version"],
            install_cmds=_get_install_cmds("winget install Microsoft.PowerShell", "brew install --cask powershell"),
            install_url="https://github.com/PowerShell/PowerShell",
        ))
    elif project_type == "Node.js":
        node_tool = _check_executable(
            name="Node.js", cmd="node", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install OpenJS.NodeJS.LTS", "brew install node"),
            install_url="https://nodejs.org/",
        )
        required_node = _read_node_version_pin(Path(directory))
        if required_node and node_tool.status == "installed":
            if not _version_meets(node_tool.version, required_node):
                node_tool.status = "outdated"
                node_tool.note = f"Requires Node {required_node}, found {node_tool.version}"
                node_tool.install_cmds = _get_install_cmds(
                    _versioned_node_install(required_node),
                    f"nvm install {required_node.split('.')[0]}"
                )
        elif required_node:
            node_tool.note = f"Project requires Node {required_node}"
        tools.append(node_tool)
        tools.append(_check_executable(
            name="npm", cmd="npm", version_args=["--version"],
            required=False,
            install_cmds=_get_install_cmds("winget install OpenJS.NodeJS.LTS", "brew install node"),
            install_url="https://nodejs.org/",
            note="Bundled with Node.js.",
        ))
        # Check if it's an Electron or React Native project
        pkg_json = d / "package.json"
        if pkg_json.exists():
            try:
                pkg = json.loads(pkg_json.read_text(encoding="utf-8", errors="ignore"))
                deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
                if "electron" in deps:
                    tools.append(ToolResult(
                        name="Electron", required=False, status="installed" if _where("electron") else "missing",
                        note="Run: npm install  to install Electron locally.",
                        install_cmd="npm install",
                    ))
                if "react-native" in deps:
                    tools.append(_check_java(required=False, min_major=11))
                    tools.append(_check_android_sdk())
            except Exception:
                pass

    elif project_type == "Python":
        py_tool = _check_executable(
            name="Python", cmd="python3" if IS_MAC else "py", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install Python.Python.3", "brew install python"),
            install_url="https://www.python.org/downloads/",
        )
        required_py = _read_python_version_pin(Path(directory))
        if required_py and py_tool.status == "installed":
            if not _version_meets(py_tool.version, required_py):
                py_tool.status = "outdated"
                py_tool.note = f"Requires Python {required_py}, found {py_tool.version}"
                py_tool.install_cmds = _get_install_cmds(
                    _versioned_python_install(required_py),
                    f"pyenv install {required_py}  # then: pyenv local {required_py}"
                )
        elif required_py:
            py_tool.note = f"Project requires Python {required_py}"
        tools.append(py_tool)
        tools.append(_check_executable(
            name="pip", cmd="pip3" if IS_MAC else "pip", version_args=["--version"],
            required=False,
            install_cmds=_get_install_cmds("py -m ensurepip", "python3 -m ensurepip"),
            install_url="https://pip.pypa.io/",
            note="Bundled with Python 3.4+.",
        ))
        # Check if requirements.txt lists any packages
        req_file = d / "requirements.txt"
        if req_file.exists():
            try:
                reqs = [
                    line.strip().split("==")[0].split(">=")[0].split("[")[0]
                    for line in req_file.read_text(encoding="utf-8").splitlines()
                    if line.strip() and not line.startswith("#")
                ]
                missing = []
                installed = []
                for pkg in reqs[:20]:  # cap at 20 to stay fast
                    try:
                        result = subprocess.run(
                            ["python3" if IS_MAC else "py", "-m", "pip", "show", pkg],
                            capture_output=True, timeout=4,
                            **SUBPROCESS_KWARGS
                        )
                        if result.returncode == 0:
                            installed.append(pkg)
                        else:
                            missing.append(pkg)
                    except Exception:
                        pass
                if installed:
                    tools.append(ToolResult(
                        name=f"Python packages ({len(installed)} installed)",
                        required=False, status="installed",
                        note=", ".join(installed[:10]) + ("..." if len(installed) > 10 else ""),
                    ))
                if missing:
                    tools.append(ToolResult(
                        name=f"Python packages ({len(missing)} missing)",
                        required=False, status="missing",
                        note=", ".join(missing[:10]),
                        install_cmd=f"pip install -r requirements.txt",
                    ))
            except Exception:
                pass

    elif project_type == "Lua":
        tools.append(_check_executable(
            name="Lua Interpreter", cmd="lua", version_args=["-v"],
            install_cmds=_get_install_cmds("winget install Lua.Lua", "brew install lua"),
            install_url="https://www.lua.org/download.html",
        ))
        tools.append(_check_executable(
            name="Luarocks", cmd="luarocks", version_args=["--version"],
            required=False,
            install_url="https://luarocks.org/",
            note="Lua package manager",
        ))

    elif project_type in ("Swift", "Swift/Xcode"):
        tools.append(_check_executable(
            name="Swift Compiler", cmd="swift", version_args=["--version"],
            install_url="https://www.swift.org/install/" if not IS_MAC else "",
            note="On macOS, install Xcode from the App Store. On Windows/Linux, see swift.org." if not IS_MAC else "Bundled with Xcode.",
        ))
        if IS_MAC:
            tools.append(_check_executable(
                name="Xcode", cmd="xcodebuild", version_args=["-version"],
                install_url="https://apps.apple.com/app/xcode/id497799835",
                note="Install from the Mac App Store.",
            ))
        if (d / "Package.swift").exists():
            tools.append(ToolResult(
                name="Swift Package Manager", required=False, status="installed",
                note="Bundled with Swift. Run: swift build",
            ))

    elif project_type == "Unreal Engine":
        tools.append(ToolResult(
            name="Unreal Engine", required=True, status="missing" if not _where("UnrealEditor") else "installed",
            install_url="https://www.unrealengine.com/download",
            note="Install via Epic Games Launcher. Open the .uproject file with Unreal Editor.",
        ))
        tools.append(_check_cpp_compiler())

    elif project_type == "Zig":
        tools.append(_check_executable(
            name="Zig", cmd="zig", version_args=["version"],
            install_cmds=_get_install_cmds("winget install zig.zig", "brew install zig"),
            install_url="https://ziglang.org/download/",
        ))

    elif project_type == "Elixir":
        tools.append(_check_executable(
            name="Elixir", cmd="elixir", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install ElixirLang.Elixir", "brew install elixir"),
            install_url="https://elixir-lang.org/install.html",
        ))
        tools.append(_check_executable(
            name="Erlang/OTP", cmd="erl", version_args=["+V"],
            required=True,
            install_cmds=_get_install_cmds("winget install ErlangSolutions.ErlangOTP", "brew install erlang"),
            install_url="https://www.erlang.org/downloads",
            note="Required runtime for Elixir.",
        ))
        tools.append(_check_executable(
            name="Mix (build tool)", cmd="mix", version_args=["--version"],
            required=False,
            note="Bundled with Elixir.",
        ))

    elif project_type == "Dart":
        tools.append(_check_executable(
            name="Dart SDK", cmd="dart", version_args=["--version"],
            install_cmds=_get_install_cmds("winget install Google.DartSDK", "brew install dart"),
            install_url="https://dart.dev/get-dart",
        ))

    elif project_type == "Scala":
        tools.append(_check_java(required=True, min_major=8))
        tools.append(_check_executable(
            name="SBT (Scala Build Tool)", cmd="sbt", version_args=["sbtVersion"],
            install_cmds=_get_install_cmds("winget install Lightbend.SBT", "brew install sbt"),
            install_url="https://www.scala-sbt.org/download.html",
        ))
        tools.append(_check_executable(
            name="Scala Compiler", cmd="scalac", version_args=["-version"],
            required=False,
            install_cmds=_get_install_cmds("winget install Scala.Scala", "brew install scala"),
            install_url="https://www.scala-lang.org/download/",
        ))

    else:
        # Unknown project — report what common tools are available
        tools.append(ToolResult(
            name="Project type not recognized",
            required=False, status="unknown",
            note="Underhood could not identify this project type. "
                 "Ensure it contains a standard manifest file "
                 "(project.godot, Cargo.toml, package.json, etc.)",
        ))

    return tools


# ── Stdlib allowlists ─────────────────────────────────────────────────────────

PYTHON_STDLIB = set(sys.stdlib_module_names) if hasattr(sys, 'stdlib_module_names') else {
    'os', 'sys', 're', 'json', 'math', 'time', 'datetime', 'pathlib', 'io',
    'collections', 'itertools', 'functools', 'typing', 'abc', 'copy',
    'hashlib', 'base64', 'struct', 'socket', 'ssl', 'http', 'urllib',
    'csv', 'sqlite3', 'logging', 'unittest', 'threading', 'subprocess',
    'shutil', 'tempfile', 'glob', 'asyncio', 'concurrent', 'contextlib',
    'dataclasses', 'enum', 'uuid', 'random', 'string', 'pprint', 'decimal',
    'queue', 'heapq', 'weakref', 'platform', 'importlib', 'zipfile', 'pickle',
    'configparser', 'argparse', 'codecs', 'traceback', 'warnings', 'inspect',
    'ast', 'gc', 'signal', 'errno', 'stat', 'builtins',
}

NODE_BUILTIN = {
    'fs', 'path', 'os', 'http', 'https', 'url', 'crypto', 'events',
    'stream', 'buffer', 'util', 'net', 'dns', 'child_process', 'cluster',
    'readline', 'assert', 'vm', 'module', 'process', 'timers', 'console',
    'querystring', 'zlib', 'tls', 'dgram', 'worker_threads',
}


class ZeroTrustSandbox:
    POPULAR_PACKAGES = {
        "python": {
            "requests", "numpy", "pandas", "urllib3", "cryptography", "flask", "django",
            "jinja2", "pip", "boto3", "wheel", "setuptools", "pytest", "black", "virtualenv",
            "pyyaml", "certifi", "six", "idna", "charset-normalizer", "python-dateutil",
            "pytz", "s3transfer", "typing-extensions", "fsspec", "click", "attrs", "async-timeout"
        },
        "node": {
            "lodash", "react", "vue", "express", "chalk", "request", "axios", "moment",
            "commander", "tslib", "uuid", "debug", "react-dom", "fs-extra", "mkdirp",
            "glob", "semver", "minimist", "bluebird", "webpack", "babel-core", "body-parser",
            "inquirer", "core-js", "dotenv", "async", "prop-types", "classnames"
        },
        "lua": {
            "luasocket", "luasec", "luafilesystem", "dkjson", "penlight", "copas", "coxpcall"
        },
        "typescript": {
            "typescript", "tsx", "ts-node", "bun", "deno", "zod", "trpc", "prisma",
            "@types/node", "@types/react", "@types/express", "prettier", "eslint"
        },
        "rust": {
            "serde", "tokio", "anyhow", "syn", "rand", "reqwest", "clap", "quote",
            "thiserror", "log", "env_logger", "futures", "bytes", "regex", "chrono"
        },
        "ruby": {
            "rails", "rake", "rspec", "puma", "bundler", "nokogiri", "json",
            "pg", "mysql2", "redis", "sidekiq", "devise", "rack"
        },
        "php": {
            "guzzlehttp/guzzle", "symfony/console", "monolog/monolog", "phpunit/phpunit",
            "psr/log", "laravel/framework", "nikic/php-parser"
        }
    }

    @staticmethod
    def edit_distance(s1: str, s2: str) -> int:
        if len(s1) > len(s2):
            s1, s2 = s2, s1
        distances = range(len(s1) + 1)
        for i2, c2 in enumerate(s2):
            distances_ = [i2+1]
            for i1, c1 in enumerate(s1):
                if c1 == c2:
                    distances_.append(distances[i1])
                else:
                    distances_.append(1 + min((distances[i1], distances[i1 + 1], distances_[-1])))
            distances = distances_
        return distances[-1]

    @classmethod
    def check_typosquatting(cls, pkg_name: str, runtime: str) -> dict | None:
        pkg_lower = pkg_name.lower().replace('_', '-').replace('.', '-')
        popular_set = cls.POPULAR_PACKAGES.get(runtime, set())
        
        # Exact match or normalized exact match is safe
        if pkg_lower in popular_set:
            return None
            
        for pop in popular_set:
            pop_norm = pop.lower().replace('_', '-').replace('.', '-')
            if pkg_lower == pop_norm:
                return None
            dist = cls.edit_distance(pkg_lower, pop_norm)
            if dist in (1, 2):
                return {
                    "resembles": pop,
                    "distance": dist
                }
        return None

    @classmethod
    def run_preflight_check(cls, pkg: str, runtime: str, vt_enabled: bool = False, vt_api_key: str = "") -> dict:
        print(f"[Zero-Trust Sandbox] Intercepting pre-flight check for package '{pkg}' ({runtime})...", file=sys.stderr, flush=True)
        typo = cls.check_typosquatting(pkg, runtime)
        if typo:
            print(f"[Zero-Trust Sandbox] Anomaly warning: '{pkg}' closely resembles popular package '{typo['resembles']}' (edit distance {typo['distance']})", file=sys.stderr, flush=True)
        
        # 1. Query Registry for metadata
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        url = None
        if runtime == 'python':
            url = f"https://pypi.org/pypi/{pkg}/json"
        elif runtime in ('node', 'typescript'):
            encoded_pkg = pkg.replace('/', '%2F')
            url = f"https://registry.npmjs.org/{encoded_pkg}"
        elif runtime == 'rust':
            url = f"https://crates.io/api/v1/crates/{pkg}"
        elif runtime == 'ruby':
            url = f"https://rubygems.org/api/v1/gems/{pkg}.json"
        elif runtime == 'php':
            url = f"https://repo.packagist.org/p2/{pkg}.json"
            
        metadata = None
        if url:
            try:
                print(f"[Zero-Trust Sandbox] Querying public registry for '{pkg}' metadata...", file=sys.stderr, flush=True)
                req = urllib.request.Request(url, headers={'User-Agent': 'Underhood-ZeroTrustSandbox/1.0'})
                with urllib.request.urlopen(req, timeout=3, context=ctx) as resp:
                    metadata = json.loads(resp.read().decode('utf-8'))
            except Exception as e:
                print(f"[Zero-Trust Sandbox] Registry metadata fetch failed for '{pkg}': {e}", file=sys.stderr, flush=True)
                pass
                
        # If registry fetch failed, we can warn or flag if typosquatting matches
        if not metadata:
            if typo:
                print(f"[Zero-Trust Sandbox] Result: SUSPICIOUS (Registry unreachable, package resembles popular '{typo['resembles']}')", file=sys.stderr, flush=True)
                return {
                    "safety": "Suspicious",
                    "details": f"Typosquatting Risk: Package resembles popular '{typo['resembles']}' (edit distance {typo['distance']}). Registry metadata unreachable."
                }
            print(f"[Zero-Trust Sandbox] Result: SAFE (Registry unreachable, no anomalies detected)", file=sys.stderr, flush=True)
            return {
                "safety": "Safe",
                "details": "Registry unreachable, no local anomalies detected."
            }

        # 2. Extract version and publish time
        is_new = False
        hours_ago = None
        latest_version = ""
        hashes = [] # list of (hash_val, download_url, filename)
        
        if runtime == 'python':
            info = metadata.get("info", {})
            latest_version = info.get("version", "")
            releases = metadata.get("releases", {})
            files = releases.get(latest_version, [])
            
            upload_time_str = None
            if files:
                upload_time_str = files[0].get("upload_time")
                for f in files:
                    digests = f.get("digests", {})
                    if "sha256" in digests:
                        hashes.append((digests["sha256"], f.get("url"), f.get("filename")))
            
            if upload_time_str:
                try:
                    upload_time_str = upload_time_str.replace('T', ' ')
                    dt = datetime.datetime.strptime(upload_time_str.split('.')[0], "%Y-%m-%d %H:%M:%S")
                    diff = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None) - dt
                    hours_ago = diff.total_seconds() / 3600.0
                    print(f"[Zero-Trust Sandbox] Latest release version {latest_version} upload time: {upload_time_str} ({hours_ago:.1f} hours ago)", file=sys.stderr, flush=True)
                    if diff.days < 2:
                        is_new = True
                        print(f"[Zero-Trust Sandbox] Anomaly warning: package '{pkg}' was published very recently (less than 48 hours ago)!", file=sys.stderr, flush=True)
                except Exception:
                    pass
                    
        elif runtime == 'node':
            dist_tags = metadata.get("dist-tags", {})
            latest_version = dist_tags.get("latest", "")
            time_dict = metadata.get("time", {})
            upload_time_str = time_dict.get(latest_version)
            
            versions = metadata.get("versions", {})
            latest_ver_data = versions.get(latest_version, {})
            dist = latest_ver_data.get("dist", {})
            sha1_hash = dist.get("shasum")
            tarball_url = dist.get("tarball")
            if sha1_hash:
                hashes.append((sha1_hash, tarball_url, f"{pkg}-{latest_version}.tgz"))
                
            if upload_time_str:
                try:
                    upload_time_str = upload_time_str.replace('Z', '').split('.')[0].replace('T', ' ')
                    dt = datetime.datetime.strptime(upload_time_str, "%Y-%m-%d %H:%M:%S")
                    diff = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None) - dt
                    hours_ago = diff.total_seconds() / 3600.0
                    print(f"[Zero-Trust Sandbox] Latest release version {latest_version} upload time: {upload_time_str} ({hours_ago:.1f} hours ago)", file=sys.stderr, flush=True)
                    if diff.days < 2:
                        is_new = True
                        print(f"[Zero-Trust Sandbox] Anomaly warning: package '{pkg}' was published very recently (less than 48 hours ago)!", file=sys.stderr, flush=True)
                except Exception:
                    pass

        # 3. Anomaly evaluation
        is_suspicious = False
        details_list = []
        
        if typo:
            is_suspicious = True
            details_list.append(f"Resembles popular package '{typo['resembles']}' (edit distance {typo['distance']})")
        if is_new:
            is_suspicious = True
            time_desc = f"{hours_ago:.1f} hours ago" if hours_ago else "recently"
            details_list.append(f"Published only {time_desc}")

        # 4. Hash lookup in VirusTotal & local download/Defender scan
        is_blocked = False
        
        if vt_enabled and vt_api_key and hashes:
            print(f"[Zero-Trust Sandbox] Cross-referencing {len(hashes)} release hash(es) with VirusTotal database...", file=sys.stderr, flush=True)
            for hash_val, _, _ in hashes:
                if cls.check_hash_on_virustotal(hash_val, vt_api_key):
                    is_blocked = True
                    print(f"[Zero-Trust Sandbox] CRITICAL: VirusTotal flagged release hash '{hash_val}' as MALICIOUS!", file=sys.stderr, flush=True)
                    details_list.append("VirusTotal flagged the release hash as malicious")
                    break

        if not is_blocked and (is_suspicious or is_new) and hashes:
            temp_dir = os.path.join(tempfile.gettempdir(), "underhood_sandbox")
            os.makedirs(temp_dir, exist_ok=True)
            for _, url, filename in hashes:
                if url:
                    try:
                        filepath = os.path.join(temp_dir, filename)
                        print(f"[Zero-Trust Sandbox] Downloading package archive to sandboxed temp path: {filename}...", file=sys.stderr, flush=True)
                        urllib.request.urlretrieve(url, filepath)
                        print(f"[Zero-Trust Sandbox] Invoking local Windows Defender scan on downloaded archive '{filename}'...", file=sys.stderr, flush=True)
                        if cls.scan_file_with_defender(filepath):
                            is_blocked = True
                            print(f"[Zero-Trust Sandbox] CRITICAL: Local Windows Defender flagged package '{filename}' as malware!", file=sys.stderr, flush=True)
                            details_list.append("Local Windows Defender flagged downloaded package as a threat")
                            try:
                                os.remove(filepath)
                            except Exception:
                                pass
                            break
                        else:
                            print(f"[Zero-Trust Sandbox] Windows Defender scan result: Clean for '{filename}'", file=sys.stderr, flush=True)
                        try:
                            os.remove(filepath)
                        except Exception:
                            pass
                    except Exception as e:
                        print(f"[Zero-Trust Sandbox] Local download/Defender scan error: {e}", file=sys.stderr, flush=True)
                        pass

        if is_blocked:
            print(f"[Zero-Trust Sandbox] Result: BLOCKED. Details: {', '.join(details_list)}", file=sys.stderr, flush=True)
            return {
                "safety": "Blocked",
                "details": f"CRITICAL THREAT: {', '.join(details_list)}."
            }
        elif is_suspicious:
            print(f"[Zero-Trust Sandbox] Result: SUSPICIOUS ANOMALY. Details: {', '.join(details_list)}", file=sys.stderr, flush=True)
            return {
                "safety": "Suspicious",
                "details": f"Anomaly behavior: {', '.join(details_list)}."
            }
        else:
            print(f"[Zero-Trust Sandbox] Result: SAFE. Package is clean.", file=sys.stderr, flush=True)
            return {
                "safety": "Safe",
                "details": f"Verified clean (Version {latest_version})."
            }

    @staticmethod
    def check_hash_on_virustotal(hash_val: str, api_key: str) -> bool:
        if not api_key:
            return False
        url = f"https://www.virustotal.com/api/v3/files/{hash_val}"
        try:
            req = urllib.request.Request(url, headers={'x-apikey': api_key})
            with urllib.request.urlopen(req, timeout=3) as resp:
                body = json.loads(resp.read().decode('utf-8'))
                mc = (body.get('data', {})
                           .get('attributes', {})
                           .get('last_analysis_stats', {})
                           .get('malicious', 0))
                return mc > 0
        except Exception:
            return False

def get_defender_path() -> str:
    # Try platform versions first
    platform_dir = r"C:\ProgramData\Microsoft\Windows Defender\Platform"
    if os.path.exists(platform_dir):
        try:
            subdirs = sorted([d for d in os.listdir(platform_dir) if os.path.isdir(os.path.join(platform_dir, d))], reverse=True)
            for sd in subdirs:
                p = os.path.join(platform_dir, sd, "MpCmdRun.exe")
                if os.path.exists(p):
                    return p
        except Exception:
            pass
    # Fallback to Program Files
    p_prog = r"C:\Program Files\Windows Defender\MpCmdRun.exe"
    return p_prog

    @staticmethod
    def scan_file_with_defender(filepath: str) -> bool:
        defender_path = get_defender_path()
        if not os.path.exists(defender_path):
            return False
        try:
            res = subprocess.run(
                [defender_path, "-Scan", "-ScanType", "3", "-File", filepath, "-DisableRemediation"],
                capture_output=True, text=True, creationflags=0x08000000
            )
            return res.returncode == 2
        except Exception:
            return False


def _scan_and_check_dependencies(project_type: str, directory: str) -> list[dict]:
    results = []
    d = Path(directory)
    if not d.is_dir():
        return results

    vt_enabled = os.environ.get('VIRUSTOTAL_ENABLED', '0').strip() == '1'
    vt_api_key = os.environ.get('VIRUSTOTAL_API_KEY', '').strip()
    runtime_map = {"Python": "python", "Node.js": "node", "Lua": "lua"}
    runtime = runtime_map.get(project_type, "python")

    def make_dep_entry(name, is_installed):
        safety = "Safe"
        safety_details = "Verified clean."
        
        # Typosquatting/Anomaly pre-flight check
        typo = ZeroTrustSandbox.check_typosquatting(name, runtime)
        if typo or not is_installed:
            check_res = ZeroTrustSandbox.run_preflight_check(name, runtime, vt_enabled, vt_api_key)
            safety = check_res["safety"]
            safety_details = check_res["details"]
            
        return {
            "name": name,
            "status": "installed" if is_installed else "missing",
            "safety": safety,
            "safety_details": safety_details
        }

    if project_type == "Python":
        found_imports = set()
        for root, dirs, files in os.walk(directory):
            dirs[:] = [
                dn for dn in dirs
                if not dn.startswith('.')
                and dn not in ('node_modules', '__pycache__', '.underhood_libs',
                               'venv', '.venv', 'env', 'dist', 'build')
            ]
            for file in files:
                if file.endswith('.py'):
                    try:
                        filepath = os.path.join(root, file)
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as fh:
                            content = fh.read()
                            for m in re.finditer(r'^\s*(?:import|from)\s+([\w\.]+)', content, re.MULTILINE):
                                found_imports.add(m.group(1))
                    except Exception:
                        pass

        # Also extract from requirements.txt
        req_file = d / "requirements.txt"
        if req_file.exists():
            try:
                for line in req_file.read_text(encoding="utf-8", errors="ignore").splitlines():
                    line = line.strip()
                    if line and not line.startswith('#'):
                        pkg = line.split("==")[0].split(">=")[0].split("<=")[0].split(">")[0].split("<")[0].split("[")[0].strip()
                        if pkg:
                            found_imports.add(pkg)
            except Exception:
                pass

        # Also extract from pyproject.toml
        pyproject = d / "pyproject.toml"
        if pyproject.exists():
            try:
                text = pyproject.read_text(encoding="utf-8", errors="ignore")
                deps_match = re.search(r'dependencies\s*=\s*\[(.*?)\]', text, re.DOTALL)
                if deps_match:
                    for dep in re.finditer(r'["\']([\w\-\.]+)', deps_match.group(1)):
                        found_imports.add(dep.group(1))
            except Exception:
                pass

        cleaned = set()
        for pkg in found_imports:
            top = pkg.split('.')[0]
            if not top:
                continue
            if top in PYTHON_STDLIB:
                continue
            if not re.match(r'^[\w\-\.]+$', top):
                continue
            cleaned.add(top)

        # Retrieve installed package distributions
        try:
            import importlib.metadata
            installed_dists = {dist.metadata['Name'].lower() for dist in importlib.metadata.distributions()}
        except Exception:
            installed_dists = set()

        import importlib.util
        underhood_libs_dir = os.path.join(directory, '.underhood_libs')
        for pkg in sorted(cleaned):
            if is_local_module(directory, pkg, "python"):
                continue
            is_installed = False
            if os.path.isdir(underhood_libs_dir):
                clean_p = pkg.replace('-', '_').lower()
                for entry in os.listdir(underhood_libs_dir):
                    entry_clean = entry.lower().replace('-', '_').split('.')[0]
                    if entry_clean == clean_p or entry.lower().startswith(f"{clean_p}-") or entry.lower().startswith(f"{clean_p}."):
                        is_installed = True
                        break
            if not is_installed:
                try:
                    if importlib.util.find_spec(pkg.replace('-', '_')) is not None:
                        is_installed = True
                except Exception:
                    pass
            if not is_installed:
                if pkg.lower() in installed_dists or pkg.replace('-', '_').lower() in installed_dists:
                    is_installed = True

            results.append(make_dep_entry(pkg, is_installed))

    elif project_type == "Node.js":
        found_imports = set()
        for root, dirs, files in os.walk(directory):
            dirs[:] = [
                dn for dn in dirs
                if not dn.startswith('.')
                and dn not in ('node_modules', 'dist', 'build', 'out')
            ]
            for file in files:
                if file.endswith(('.js', '.ts', '.jsx', '.tsx', '.mjs', '.cjs')):
                    try:
                        filepath = os.path.join(root, file)
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as fh:
                            content = fh.read()
                            for m in re.finditer(r'require\(["\']([^"\']+)["\']\)', content):
                                found_imports.add(m.group(1))
                            for m in re.finditer(r'^\s*import\s+(?:.*\s+from\s+)?["\']([^"\']+)["\']', content, re.MULTILINE):
                                found_imports.add(m.group(1))
                    except Exception:
                        pass

        # Also parse package.json
        pkg_json = d / "package.json"
        if pkg_json.exists():
            try:
                data = json.loads(pkg_json.read_text(encoding="utf-8", errors="ignore"))
                deps = {**data.get("dependencies", {}), **data.get("devDependencies", {})}
                for dep in deps.keys():
                    found_imports.add(dep)
            except Exception:
                pass

        cleaned = set()
        for pkg in found_imports:
            if pkg.startswith('.'):
                continue
            parts = pkg.split('/')
            if pkg.startswith('@') and len(parts) >= 2:
                top = parts[0] + '/' + parts[1]
            else:
                top = parts[0]
            if not top or top in NODE_BUILTIN:
                continue
            if not re.match(r'^@?[\w\-\./]+$', top):
                continue
            cleaned.add(top)

        node_modules_path = os.path.join(directory, 'node_modules')
        for pkg in sorted(cleaned):
            is_installed = False
            if os.path.isdir(node_modules_path):
                pkg_dir = os.path.join(node_modules_path, *pkg.split('/'))
                if os.path.isdir(pkg_dir):
                    is_installed = True
            
            results.append(make_dep_entry(pkg, is_installed))

    elif project_type == "Lua":
        found_imports = set()
        for root, dirs, files in os.walk(directory):
            dirs[:] = [
                dn for dn in dirs
                if not dn.startswith('.')
                and dn not in ('node_modules', 'dist', 'build', 'out')
            ]
            for file in files:
                if file.endswith('.lua'):
                    try:
                        filepath = os.path.join(root, file)
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as fh:
                            content = fh.read()
                            for m in re.finditer(r'require\(["\']([^"\']+)["\']\)', content):
                                found_imports.add(m.group(1))
                    except Exception:
                        pass

        # Parse .rockspec if exists
        try:
            rockspecs = list(d.glob("*.rockspec"))
            if rockspecs:
                text = rockspecs[0].read_text(encoding="utf-8", errors="ignore")
                # regex to find items in dependencies block
                deps_match = re.search(r'dependencies\s*=\s*\{(.*?)\}', text, re.DOTALL)
                if deps_match:
                    for dep in re.finditer(r'["\']([\w\-\.]+)', deps_match.group(1)):
                        if dep.group(1) != "lua":
                            found_imports.add(dep.group(1))
        except Exception:
            pass

        cleaned = set()
        for pkg in found_imports:
            if not re.match(r'^[\w\-\.]+$', pkg):
                continue
            cleaned.add(pkg)

        # Check which ones are installed (without spawning a command for every package, we can try running luarocks show)
        for pkg in sorted(cleaned):
            is_installed = False
            try:
                res = subprocess.run(
                    ["luarocks", "show", pkg],
                    capture_output=True, timeout=2,
                    **SUBPROCESS_KWARGS
                )
                if res.returncode == 0:
                    is_installed = True
            except Exception:
                pass
            results.append(make_dep_entry(pkg, is_installed))

    return results


def _get_package_managers() -> list[ToolResult]:
    pms = []
    if IS_MAC:
        pms.append(_check_executable(
            name="Homebrew (brew)", cmd="brew", version_args=["--version"], required=False,
            install_cmd='/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"',
            install_url="https://brew.sh/",
            note="Underhood uses Homebrew to install missing tools. Install this to easily resolve dependencies."
        ))
    else:
        pms.append(_check_executable(
            name="Winget", cmd="winget", version_args=["--version"], required=False,
            install_cmd="Invoke-WebRequest -Uri https://github.com/microsoft/winget-cli/releases/latest/download/Microsoft.DesktopAppInstaller_8wekyb3d8bbwe.msixbundle -OutFile $env:TEMP\\winget.msixbundle; Add-AppxPackage $env:TEMP\\winget.msixbundle",
            install_url="https://github.com/microsoft/winget-cli",
            note="Underhood uses Winget to install missing tools. Install this to easily resolve dependencies."
        ))
        pms.append(_check_executable(
            name="Chocolatey (choco)", cmd="choco", version_args=["--version"], required=False,
            install_cmd="Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))",
            install_url="https://chocolatey.org/install",
            note="Underhood uses Chocolatey to install missing tools. Install this to easily resolve dependencies."
        ))
        pms.append(_check_executable(
            name="Scoop", cmd="scoop", version_args=["--version"], required=False,
            install_cmd="Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser; Invoke-RestMethod -Uri https://get.scoop.sh | Invoke-Expression",
            install_url="https://scoop.sh/",
            note="Underhood uses Scoop to install missing tools. Install this to easily resolve dependencies."
        ))
    return pms


# ── Main analyzer class ───────────────────────────────────────────────────────

class ProjectAnalyzer:
    def __init__(self, directory: str):
        self.directory = os.path.abspath(directory)

    def analyze(self) -> AnalysisResult:
        project_type, project_name, project_version, project_dir_path = _detect_project_type(self.directory)

        tools = _get_tools_for(project_type, project_dir_path)
        tools.extend(_get_package_managers())


        dep_report = _scan_and_check_dependencies(project_type, project_dir_path)

        result = AnalysisResult(
            project_type=project_type,
            project_name=project_name,
            project_version=project_version,
            project_icon=PROJECT_ICONS.get(project_type, "📁"),
            directory=project_dir_path,
            tools=tools,
            dep_report=dep_report,
        )

        # Compute blockers
        for t in tools:
            if t.required and t.status in ("missing", "outdated"):
                result.blockers.append(
                    f"{t.name}: {t.note or 'Not installed'}"
                    + (f"\n  Install: {t.install_cmd}" if t.install_cmd else "")
                )

        for dep in dep_report:
            if dep.get("safety") == "Blocked":
                result.blockers.append(
                    f"Dependency Threat: {dep['name']} - {dep['safety_details']}"
                )

        result.can_run = len(result.blockers) == 0
        return result


# ── CLI entry point ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: analyzer.py <project_folder>", file=sys.stderr)
        sys.exit(1)

    folder = sys.argv[1]
    analyzer = ProjectAnalyzer(folder)
    result = analyzer.analyze()
    print(result.to_json())
    sys.exit(0 if result.can_run else 1)
