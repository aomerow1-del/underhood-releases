"""
engine/runner.py — Underhood Runner
=====================================
Entry point called by the Rust sidecar.

Phase 1: ProjectAnalyzer — detects project type, checks all required tools.
Phase 2: If the project is runnable (Python/Node/Lua with an entry script),
         execute it with auto-repair for missing packages.

Output: single JSON line on stdout (parsed by the Rust backend).
"""

from __future__ import annotations
from pathlib import Path

import asyncio
import datetime
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import sys
import urllib.error
import urllib.request

IS_WINDOWS = sys.platform == "win32"
PYTHON_EXE = "py" if IS_WINDOWS else "python3"

# Import the new universal analyzer
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analyzer import ProjectAnalyzer, ZeroTrustSandbox

# ── Registry integration for settings and history ─────────────────────────────

def load_windows_registry_settings() -> dict:
    settings = {}
    if sys.platform != "win32":
        return settings
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Underhood") as key:
            try:
                settings['HuggingFaceToken'] = winreg.QueryValueEx(key, 'HuggingFaceToken')[0]
            except OSError:
                pass
            try:
                settings['SecurityEngine'] = winreg.QueryValueEx(key, 'SecurityEngine')[0]
            except OSError:
                pass
            try:
                settings['VirusTotalApiKey'] = winreg.QueryValueEx(key, 'VirusTotalApiKey')[0]
            except OSError:
                pass
            try:
                settings['VirusTotalEnabled'] = winreg.QueryValueEx(key, 'VirusTotalEnabled')[0]
            except OSError:
                pass
            try:
                settings['SecretsScanEnabled'] = winreg.QueryValueEx(key, 'SecretsScanEnabled')[0]
            except OSError:
                pass
    except Exception:
        pass
    return settings

# Load registry settings on Windows and set as environment fallback
reg_settings = load_windows_registry_settings()
if 'HF_TOKEN' not in os.environ and reg_settings.get('HuggingFaceToken'):
    os.environ['HF_TOKEN'] = reg_settings['HuggingFaceToken']
if 'SECURITY_ENGINE' not in os.environ and reg_settings.get('SecurityEngine'):
    os.environ['SECURITY_ENGINE'] = reg_settings['SecurityEngine']
if 'VIRUSTOTAL_API_KEY' not in os.environ and reg_settings.get('VirusTotalApiKey'):
    os.environ['VIRUSTOTAL_API_KEY'] = reg_settings['VirusTotalApiKey']
if 'VIRUSTOTAL_ENABLED' not in os.environ:
    vt_enabled = reg_settings.get('VirusTotalEnabled')
    if vt_enabled is not None:
        os.environ['VIRUSTOTAL_ENABLED'] = '1' if vt_enabled else '0'
if 'SECRETS_SCAN_ENABLED' not in os.environ:
    sec_enabled = reg_settings.get('SecretsScanEnabled')
    if sec_enabled is not None:
        os.environ['SECRETS_SCAN_ENABLED'] = '1' if sec_enabled else '0'

def log_scan_history(project_dir: str, project_type: str, success: bool):
    if sys.platform != "win32":
        return
    if os.environ.get('UNDERHOOD_GUI') == '1':
        return
    try:
        import winreg
        import datetime
        
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status = "Success" if success else "Failed"
        new_entry = {
            "FolderPath": project_dir,
            "ProjectType": project_type,
            "Status": status,
            "Timestamp": timestamp
        }
        
        history_json = "[]"
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Underhood") as key:
                history_json = winreg.QueryValueEx(key, 'ScanHistory')[0]
        except OSError:
            pass
            
        try:
            history = json.loads(history_json)
            if not isinstance(history, list):
                history = []
        except Exception:
            history = []
            
        # Append new entry at the beginning
        history.insert(0, new_entry)
        history = history[:50] # Limit to 50 items
        
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Underhood") as key:
            winreg.SetValueEx(key, 'ScanHistory', 0, winreg.REG_SZ, json.dumps(history))
    except Exception as e:
        print(f"Error saving scan history: {e}", file=sys.stderr)

def generate_html_report(res: dict, project_path: str):
    import datetime
    import html
    
    report_path = os.path.join(project_path, "underhood_scan_report.html")
    try:
        test_file = os.path.join(project_path, ".underhood_tmp")
        with open(test_file, 'w') as f:
            pass
        os.remove(test_file)
    except Exception:
        fallback_dir = os.path.join(os.environ.get('LOCALAPPDATA', ''), "Underhood", "reports")
        os.makedirs(fallback_dir, exist_ok=True)
        report_path = os.path.join(fallback_dir, f"report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
        
    safety_status = "CLEAN"
    banner_style = "clean"
    safety_icon = "✓"
    
    vt = res.get("vt_scan", {})
    dep_report = res.get("dep_report", [])
    tools = res.get("tools", [])
    blockers = res.get("blockers", [])
    stdout = res.get("stdout", "")
    stderr = res.get("stderr", "")
    
    if vt.get("enabled") and len(vt.get("malicious", [])) > 0:
        safety_status = "INFECTED (MALWARE DETECTED)"
        banner_style = "infected"
        safety_icon = "✗"
    elif any(d.get("safety") == "Blocked" for d in dep_report):
        safety_status = "INFECTED (BLOCKED DEPENDENCY)"
        banner_style = "infected"
        safety_icon = "✗"
    elif any(d.get("safety") == "Suspicious" for d in dep_report):
        safety_status = "SUSPICIOUS (QUARANTINED)"
        banner_style = "suspicious"
        safety_icon = "⚠️"
    elif any(t.get("required") and t.get("status") == "missing" for t in tools):
        safety_status = "MISSING DEPENDENCIES"
        banner_style = "missing"
        safety_icon = "🔧"
    elif stderr and ("Exception" in stderr or "Error" in stderr or len(blockers) > 0):
        safety_status = "EXECUTION ERROR"
        banner_style = "error"
        safety_icon = "⚠"
        
    tools_html = []
    for tool in tools:
        status = tool.get("status", "missing")
        if status == "installed":
            status_badge = '<span class="badge badge-installed">Installed</span>'
        elif status == "outdated":
            status_badge = '<span class="badge badge-outdated">Outdated</span>'
        else:
            status_badge = '<span class="badge badge-missing">Missing</span>'
            
        req_badge = '<span class="badge badge-required">Required</span>' if tool.get("required") else '<span class="badge badge-optional">Optional</span>'
        
        tools_html.append(f"""
        <tr>
            <td style="font-weight: bold; color: #ffffff;">{html.escape(tool.get('name', ''))}</td>
            <td style="font-family: monospace;">{html.escape(tool.get('version', '') or '—')}</td>
            <td style="color: #94a3b8; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{html.escape(tool.get('path', '') or '')}">{html.escape(tool.get('path', '') or '—')}</td>
            <td>{req_badge}</td>
            <td style="text-align: right;">{status_badge}</td>
        </tr>""")
    tools_rows = "".join(tools_html)
    
    deps_html = []
    if not dep_report:
        deps_rows = '<tr><td colspan="4" style="padding: 24px; text-align: center; color: #64748b; font-size: 13px;">No application dependencies scanned.</td></tr>'
    else:
        for dep in dep_report:
            status = dep.get("status", "missing")
            if status == "installed":
                status_badge = '<span class="badge badge-installed">Installed</span>'
            elif status == "installed (auto)":
                status_badge = '<span class="badge badge-installed">Installed (auto)</span>'
            else:
                status_badge = '<span class="badge badge-missing">Missing</span>'
                
            safety = dep.get("safety", "Safe")
            if safety == "Safe":
                safety_badge = '<span class="badge badge-safe">Safe</span>'
            elif safety == "Suspicious":
                safety_badge = '<span class="badge badge-suspicious">Suspicious</span>'
            else:
                safety_badge = '<span class="badge badge-blocked">Blocked</span>'
                
            deps_html.append(f"""
            <tr>
                <td style="font-weight: bold; color: #ffffff;">{html.escape(dep.get('name', ''))}</td>
                <td>{status_badge}</td>
                <td>{safety_badge}</td>
                <td style="color: #cbd5e1;">{html.escape(dep.get('safety_details', '') or '—')}</td>
            </tr>""")
        deps_rows = "".join(deps_html)
        
    security_status_html = ""
    if vt.get("enabled"):
        engine_name = os.environ.get('SECURITY_ENGINE', 'VirusTotal')
        engine_display = "Windows Defender" if engine_name == "WindowsDefender" else "VirusTotal"
        is_clean = vt.get("clean", True)
        color_class = "scanner-clean" if is_clean else "scanner-malicious"
        summary_msg = "All files scanned clean." if is_clean else f"Malware/threats flagged: {len(vt.get('malicious', []))}"
        if vt.get("api_errors", 0) > 0:
            color_class = "scanner-malicious"
            summary_msg = vt.get("error_message") or "API error or timeout encountered during scan."
            
        security_status_html = f"""
        <div class="scanner-report">
            <div class="scanner-info">
                <h3>🛡️ {engine_display} Active Scan Report</h3>
                <p>Scanned project files recursively for binary and script signature anomalies.</p>
            </div>
            <div class="scanner-badge-container">
                <div class="scanner-badge {color_class}">
                    Files Scanned: {vt.get('files_scanned', 0)} | {summary_msg}
                </div>
            </div>
        </div>"""
        
    secrets = res.get('secrets_scan', {})
    secrets_findings = secrets.get('findings', [])
    secrets_counts   = secrets.get('counts', {})
    secrets_total    = secrets.get('total', 0)

    esc_stdout = html.escape(stdout or "")
    esc_stderr = html.escape(stderr or "")
    logs_section_html = ""
    if esc_stdout or esc_stderr:
        stdout_block = f"""
        <div style="margin-bottom: 15px;">
            <div class="log-label">Standard Output</div>
            <pre class="stdout-log">{esc_stdout}</pre>
        </div>""" if esc_stdout else ""
        
        stderr_block = f"""
        <div>
            <div class="log-label">Standard Error / Logs</div>
            <pre class="stderr-log">{esc_stderr}</pre>
        </div>""" if esc_stderr else ""
        
        logs_section_html = f"""
        <div class="card">
            <h2 class="card-title" style="margin-bottom: 15px;">💻 Execution Logs</h2>
            {stdout_block}
            {stderr_block}
        </div>"""

    # ── Secrets scan card ──────────────────────────────────────────────────────
    sev_colors = {
        'CRITICAL': ('#fca5a5', 'rgba(239,68,68,0.18)', '#ef4444'),
        'HIGH':     ('#fcd34d', 'rgba(245,158,11,0.18)', '#f59e0b'),
        'MEDIUM':   ('#fde68a', 'rgba(234,179,8,0.18)',  '#ca8a04'),
        'LOW':      ('#a5f3fc', 'rgba(6,182,212,0.15)',  '#0891b2'),
    }
    if not secrets.get('enabled', True):
        secrets_card_html = f"""
        <div class="card" style="margin-bottom:24px;">
          <div class="card-header">
            <div class="card-header-left"><h2 class="card-title">🔐 Secrets &amp; Sensitive Data Scan</h2></div>
            <div class="card-header-right"><span style="font-size:11px;color:#94a3b8;background:#1f2937;padding:2px 8px;border-radius:10px;">Scan Disabled</span></div>
          </div>
          <div style="padding:20px;text-align:center;background:rgba(148,163,184,0.08);border-radius:10px;border:1px solid rgba(148,163,184,0.2);">
            <span style="font-size:24px;">🛡️</span>
            <p style="margin:8px 0 0;color:#94a3b8;font-weight:700;">Secrets &amp; sensitive data scanning is disabled</p>
            <p style="margin:4px 0 0;color:#64748b;font-size:12px;">Enable Secrets Scanning in settings to scan project files for leaks.</p>
          </div>
        </div>"""
    elif secrets_total == 0:
        secrets_card_html = f"""
        <div class="card" style="margin-bottom:24px;">
          <div class="card-header">
            <div class="card-header-left"><h2 class="card-title">🔐 Secrets &amp; Sensitive Data Scan</h2></div>
            <div class="card-header-right"><span style="font-size:11px;color:#94a3b8;background:#1f2937;padding:2px 8px;border-radius:10px;">{secrets.get('files_scanned',0)} files scanned</span></div>
          </div>
          <div style="padding:20px;text-align:center;background:rgba(16,185,129,0.08);border-radius:10px;border:1px solid rgba(16,185,129,0.2);">
            <span style="font-size:24px;">✅</span>
            <p style="margin:8px 0 0;color:#34d399;font-weight:700;">No secrets or sensitive data detected</p>
            <p style="margin:4px 0 0;color:#64748b;font-size:12px;">Scanned for API keys, tokens, passwords, PII, and credentials.</p>
          </div>
        </div>"""
    else:
        # Overall badge colour = worst severity found
        worst = 'LOW'
        for sev in ('CRITICAL','HIGH','MEDIUM','LOW'):
            if secrets_counts.get(sev, 0) > 0:
                worst = sev
                break
        wfg, wbg, wborder = sev_colors[worst]
        badge_counts = ' · '.join(
            f'<span style="color:{sev_colors[s][0]};font-weight:700;">{s}: {secrets_counts.get(s,0)}</span>'
            for s in ('CRITICAL','HIGH','MEDIUM','LOW') if secrets_counts.get(s, 0) > 0
        )
        rows = []
        for f in secrets_findings:
            fg, bg, border = sev_colors.get(f['severity'], sev_colors['LOW'])
            rows.append(f"""
            <tr>
              <td style="font-family:monospace;font-size:12px;color:#94a3b8;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="{html.escape(f['file'])}">{html.escape(f['file'])}</td>
              <td style="font-family:monospace;font-size:12px;color:#64748b;text-align:right;">{f['line']}</td>
              <td><span style="font-size:11px;padding:2px 8px;border-radius:99px;background:{bg};color:{fg};border:1px solid {border};font-weight:700;">{html.escape(f['category'])}</span></td>
              <td><span style="font-size:11px;padding:2px 8px;border-radius:99px;background:{bg};color:{fg};border:1px solid {border};font-weight:700;">{html.escape(f['severity'])}</span></td>
              <td style="font-family:monospace;font-size:12px;color:#cbd5e1;">{html.escape(f['preview'])}</td>
            </tr>""")
        rows_html = ''.join(rows)
        secrets_card_html = f"""
        <div class="card" style="margin-bottom:24px;border-color:{wborder};">
          <div class="card-header">
            <div class="card-header-left"><h2 class="card-title">🔐 Secrets &amp; Sensitive Data Scan</h2></div>
            <div class="card-header-right" style="display:flex;gap:8px;align-items:center;">
              <span style="font-size:11px;color:#94a3b8;background:#1f2937;padding:2px 8px;border-radius:10px;">{secrets.get('files_scanned',0)} files scanned</span>
              <span style="font-size:12px;padding:3px 10px;border-radius:99px;background:{wbg};color:{wfg};border:1px solid {wborder};font-weight:700;">⚠ {secrets_total} finding{'s' if secrets_total!=1 else ''}</span>
            </div>
          </div>
          <div style="margin-bottom:12px;padding:10px 14px;background:rgba(0,0,0,0.2);border-radius:8px;font-size:13px;">{badge_counts}</div>
          <div class="card-subtitle">Values are redacted for safety. Review flagged files and rotate any exposed credentials immediately.</div>
          <div class="table-responsive">
            <table>
              <thead><tr><th>File</th><th style="text-align:right;">Line</th><th>Category</th><th>Severity</th><th>Preview (redacted)</th></tr></thead>
              <tbody>{rows_html}</tbody>
            </table>
          </div>
        </div>"""
        
    project_title = f"— {res.get('project_name', '')} {res.get('project_version', '')}" if res.get('project_name') else ""
    tools_summary_rows = "".join(f"""
    <tr>
        <td style="font-weight: bold; color: #ffffff;">{html.escape(t.get('name', ''))}</td>
        <td style="font-family: monospace; font-size: 11px; color: #94a3b8;">{html.escape(t.get('version', '') or '—')}</td>
        <td style="text-align: right;">
            {'<span style="font-size: 11px; font-weight: bold; color: #34d399;">✓ Installed</span>' if t.get('status') == 'installed' else ('<span style="font-size: 11px; font-weight: bold; color: #fbbf24;">⚠ Outdated</span>' if t.get('status') == 'outdated' else '<span style="font-size: 11px; font-weight: bold; color: #f87171;">✗ Missing</span>')}
        </td>
    </tr>""" for t in tools)
    
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Underhood Security Scan Report</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {{
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
            background-color: #090d16;
            color: #f8fafc;
            margin: 0;
            padding: 0 0 50px 0;
        }}
        .container {{
            max-width: 1000px;
            margin: 0 auto;
            padding: 30px 20px;
        }}
        .header {{
            border-bottom: 1px solid #1f2937;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }}
        .header::after {{
            content: "";
            display: table;
            clear: both;
        }}
        .header-brand {{
            float: left;
        }}
        .logo-icon {{
            float: left;
            font-size: 28px;
            margin-right: 12px;
        }}
        .brand-title {{
            margin: 0;
            font-size: 22px;
            font-weight: 800;
            color: #ffffff;
            line-height: 1.2;
        }}
        .brand-subtitle {{
            margin: 0;
            color: #64748b;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1.5px;
        }}
        .header-meta {{
            float: right;
            text-align: right;
        }}
        .meta-label {{
            font-size: 11px;
            color: #94a3b8;
        }}
        .meta-value {{
            font-size: 14px;
            font-weight: 600;
            color: #e2e8f0;
        }}
        
        .banner-card {{
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 30px;
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .banner-card::after {{
            content: "";
            display: table;
            clear: both;
        }}
        .banner-left {{
            float: left;
            width: 60%;
        }}
        .banner-right {{
            float: right;
            width: 35%;
            text-align: right;
        }}
        .banner-card.clean {{
            background: linear-gradient(135deg, #064e3b, #047857);
            background-color: #064e3b;
        }}
        .banner-card.infected {{
            background: linear-gradient(135deg, #7f1d1d, #b91c1c);
            background-color: #7f1d1d;
        }}
        .banner-card.suspicious {{
            background: linear-gradient(135deg, #78350f, #d97706);
            background-color: #78350f;
        }}
        .banner-card.missing {{
            background: linear-gradient(135deg, #7c2d12, #ea580c);
            background-color: #7c2d12;
        }}
        .banner-card.error {{
            background: linear-gradient(135deg, #374151, #4b5563);
            background-color: #374151;
        }}
        
        .banner-badge {{
            background: rgba(255, 255, 255, 0.15);
            color: #ffffff;
            padding: 4px 10px;
            border-radius: 99px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: inline-block;
        }}
        .banner-title {{
            margin: 15px 0 10px 0;
            font-size: 28px;
            font-weight: 800;
            color: #ffffff;
        }}
        .banner-path {{
            margin: 0;
            font-size: 13px;
            color: rgba(255, 255, 255, 0.9);
        }}
        .banner-path span {{
            font-family: monospace;
            background: rgba(0, 0, 0, 0.2);
            padding: 2px 6px;
            border-radius: 4px;
        }}
        .banner-project-box {{
            background: rgba(0, 0, 0, 0.15);
            padding: 12px 18px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            display: inline-block;
            text-align: left;
        }}
        .project-box-label {{
            font-size: 11px;
            color: rgba(255, 255, 255, 0.6);
            font-weight: 600;
        }}
        .project-box-value {{
            font-size: 16px;
            font-weight: 700;
            color: #ffffff;
            margin-top: 2px;
        }}
        
        .section-row {{
            margin-bottom: 30px;
        }}
        .section-row::after {{
            content: "";
            display: table;
            clear: both;
        }}
        .section-col-large {{
            float: left;
            width: 65%;
            box-sizing: border-box;
        }}
        .section-col-small {{
            float: right;
            width: 32%;
            box-sizing: border-box;
        }}
        
        .card {{
            background-color: #111827;
            border: 1px solid #1f2937;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-sizing: border-box;
        }}
        .card-header {{
            border-bottom: 1px solid #1f2937;
            padding-bottom: 12px;
            margin-bottom: 15px;
        }}
        .card-header::after {{
            content: "";
            display: table;
            clear: both;
        }}
        .card-header-left {{
            float: left;
        }}
        .card-header-right {{
            float: right;
            margin-top: 2px;
        }}
        .card-title {{
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            color: #f1f5f9;
        }}
        .card-subtitle {{
            font-size: 12px;
            color: #94a3b8;
            margin-top: 4px;
            margin-bottom: 20px;
            line-height: 1.4;
        }}
        
        .table-responsive {{
            overflow-x: auto;
            width: 100%;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }}
        th {{
            border-bottom: 2px solid #1f2937;
            padding: 10px 12px;
            font-size: 11px;
            font-weight: 600;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        td {{
            border-bottom: 1px solid #1f2937;
            padding: 12px;
            font-size: 13px;
            color: #cbd5e1;
            vertical-align: middle;
        }}
        tr:hover td {{
            background-color: rgba(31, 41, 55, 0.4);
        }}
        
        .badge {{
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 700;
            display: inline-block;
            border: 1px solid transparent;
        }}
        .badge-installed {{ background-color: rgba(16, 185, 129, 0.15); color: #34d399; border-color: rgba(16, 185, 129, 0.25); }}
        .badge-outdated {{ background-color: rgba(245, 158, 11, 0.15); color: #fbbf24; border-color: rgba(245, 158, 11, 0.25); }}
        .badge-missing {{ background-color: rgba(239, 68, 68, 0.15); color: #f87171; border-color: rgba(239, 68, 68, 0.25); }}
        .badge-optional {{ background-color: rgba(100, 116, 139, 0.15); color: #94a3b8; border-color: rgba(100, 116, 139, 0.25); }}
        .badge-required {{ background-color: rgba(168, 85, 247, 0.15); color: #c084fc; border-color: rgba(168, 85, 247, 0.25); }}
        .badge-safe {{ background-color: rgba(16, 185, 129, 0.15); color: #34d399; border-color: rgba(16, 185, 129, 0.25); }}
        .badge-suspicious {{ background-color: rgba(245, 158, 11, 0.15); color: #fbbf24; border-color: rgba(245, 158, 11, 0.25); }}
        .badge-blocked {{ background-color: rgba(239, 68, 68, 0.15); color: #f87171; border-color: rgba(239, 68, 68, 0.25); }}

        .scanner-report {{
            background-color: rgba(17, 24, 39, 0.6);
            border: 1px solid #1f2937;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 24px;
        }}
        .scanner-report::after {{
            content: "";
            display: table;
            clear: both;
        }}
        .scanner-info {{
            float: left;
            width: 65%;
        }}
        .scanner-info h3 {{
            margin: 0;
            font-size: 14px;
            color: #e2e8f0;
        }}
        .scanner-info p {{
            margin: 4px 0 0 0;
            font-size: 12px;
            color: #94a3b8;
        }}
        .scanner-badge-container {{
            float: right;
            margin-top: 4px;
        }}
        .scanner-badge {{
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            display: inline-block;
            border: 1px solid transparent;
        }}
        .scanner-clean {{ background-color: rgba(16, 185, 129, 0.1); color: #34d399; border-color: rgba(16, 185, 129, 0.25); }}
        .scanner-malicious {{ background-color: rgba(239, 68, 68, 0.1); color: #f87171; border-color: rgba(239, 68, 68, 0.25); }}
        
        pre {{
            background-color: #05070f;
            padding: 15px;
            border-radius: 10px;
            font-family: Consolas, Monaco, monospace;
            font-size: 12px;
            overflow-x: auto;
            margin: 0;
            border: 1px solid #1f2937;
        }}
        .stdout-log {{ color: #34d399; }}
        .stderr-log {{ color: #f87171; }}
        .log-label {{
            font-size: 11px;
            color: #94a3b8;
            font-weight: 600;
            margin-bottom: 6px;
            text-transform: uppercase;
        }}
        @media (max-width: 768px) {{
            .header-brand, .header-meta, .banner-left, .banner-right, .section-col-large, .section-col-small, .scanner-info, .scanner-badge-container {{
                float: none !important;
                width: 100% !important;
                text-align: left !important;
                margin-bottom: 15px;
            }}
            .banner-right, .scanner-badge-container {{
                margin-bottom: 0;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Brand -->
        <div class="header">
            <div class="header-brand">
                <span class="logo-icon">🛡️</span>
                <div>
                    <h1 class="brand-title">Underhood</h1>
                    <p class="brand-subtitle">Zero-Trust Pre-flight Analyzer</p>
                </div>
            </div>
            <div class="header-meta">
                <div class="meta-label">Generated</div>
                <div class="meta-value">{timestamp}</div>
            </div>
        </div>

        <!-- Overall Status Banner -->
        <div class="banner-card {banner_style}">
            <div class="banner-left">
                <span class="banner-badge">Project Resolution Safe Check</span>
                <h2 class="banner-title">{safety_icon} {safety_status}</h2>
                <p class="banner-path">Directory: <span>{project_path}</span></p>
            </div>
            <div class="banner-right">
                <div class="banner-project-box">
                    <div class="project-box-label">Detected Project Type</div>
                    <div class="project-box-value">📦 {res.get('project_type', 'Unknown')} {project_title}</div>
                </div>
            </div>
        </div>

        <!-- Active Security Scanner -->
        {security_status_html}

        <!-- Two column details layout -->
        <div class="section-row">
            <!-- Sandbox Checks: 2 Cols -->
            <div class="section-col-large card">
                <div class="card-header">
                    <div class="card-header-left">
                        <h2 class="card-title">📦 Sandbox Pre-flight Checks</h2>
                    </div>
                    <div class="card-header-right">
                        <span style="font-size: 11px; color: #94a3b8; background-color: #1f2937; padding: 2px 8px; border-radius: 10px;">{len(dep_report)} dependencies</span>
                    </div>
                </div>
                <div class="card-subtitle">Pre-flight checks analyze registry metrics, typosquatting vectors, and scan downloaded packages inside an isolated sandbox prior to execution.</div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Package Name</th>
                                <th>System State</th>
                                <th>Sandbox Safety</th>
                                <th>Scan Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            {deps_rows}
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Required Dev Tools: 1 Col -->
            <div class="section-col-small card">
                <h2 class="card-title" style="margin-bottom: 5px;">🔧 Required Dev Tools</h2>
                <div class="card-subtitle">Runtimes and installation status required to launch and compile this project locally.</div>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Tool</th>
                                <th>Version</th>
                                <th style="text-align: right;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {tools_summary_rows}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Toolchain Paths detailed table -->
        <div class="card">
            <h2 class="card-title" style="margin-bottom: 15px;">📂 Toolchain Paths</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Tool</th>
                            <th>Detected Version</th>
                            <th>System Path</th>
                            <th>Priority</th>
                            <th style="text-align: right;">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tools_rows}
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Terminal Output logs -->
        {logs_section_html}

        <!-- Secrets & Sensitive Data Scan -->
        {secrets_card_html}

        <!-- Footer -->
        <div style="text-align: center; color: #64748b; font-size: 11px; margin-top: 50px; border-top: 1px solid #1f2937; padding-top: 20px;">
            <p>Underhood Zero-Trust Smart Sandbox checking is a proactive developer environment safety gateway.</p>
            <p style="margin-top: 5px;">&copy; {datetime.datetime.now().year} Underhood Security Engine. All rights reserved.</p>
        </div>
    </div>
</body>
</html>"""
    try:
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
    except Exception as e:
        print(f"Error generating HTML report: {e}", file=sys.stderr)

def finalize_scan(result: dict, project_dir: str):
    success = result.get("can_run", False) and not (result.get("vt_scan", {}).get("enabled") and len(result.get("vt_scan", {}).get("malicious", [])) > 0)
    log_scan_history(project_dir, result.get("project_type", "Unknown"), success)
    generate_html_report(result, project_dir)


# ── VirusTotal hash scanner (stdlib only, no new deps) ─────────────────────────

VT_SCAN_EXTENSIONS = {'.exe', '.dll', '.so', '.py', '.js'}

def get_defender_path() -> str:
    # Try platform versions first
    platform_dir = r"C:\ProgramData\Microsoft\Windows Defender\Platform"
    if os.path.exists(platform_dir):
        try:
            subdirs = sorted([d for d in os.listdir(platform_dir) if os.path.isdir(os.path.join(platform_dir, d))], reverse=True)
            for sd in subdirs:
                p = os.path.join(platform_dir, sd, "MpCmdRun.exe")
                if os.path.exists(p):
                    return p
        except Exception:
            pass
    # Fallback to Program Files
    p_prog = r"C:\Program Files\Windows Defender\MpCmdRun.exe"
    return p_prog

def _scan_with_defender(project_dir: str) -> dict:
    defender_path = get_defender_path()
    if not os.path.exists(defender_path):
        return {
            'enabled': True, 'files_scanned': 0, 'malicious': [],
            'clean': False, 'api_errors': 1,
            'error_message': f'Windows Defender not found at {defender_path}'
        }

    print(f"[Zero-Trust Sandbox] Invoking local Windows Defender scan on directory '{project_dir}' using '{defender_path}'...", file=sys.stderr, flush=True)

    try:
        # MpCmdRun exit codes: 0 = clean, 2 = threat detected.
        # Any other code (e.g. 13 = access denied / needs elevation,
        # -1073741515 = DLL not found, etc.) is a SCAN ERROR, NOT a threat.
        res = subprocess.run(
            [defender_path, "-Scan", "-ScanType", "3", "-File", project_dir, "-DisableRemediation"],
            capture_output=True, text=True, timeout=120
        )
        if res.returncode == 0:
            return {
                'enabled': True, 'files_scanned': 1, 'malicious': [],
                'clean': True, 'api_errors': 0, 'error_message': ''
            }
        elif res.returncode == 2:
            return {
                'enabled': True, 'files_scanned': 1, 'malicious': [project_dir],
                'clean': False, 'api_errors': 0,
                'error_message': 'Windows Defender detected a threat in the project directory.'
            }
        else:
            # Unexpected exit code — treat as a scan error, not a threat
            stderr_hint = (res.stderr or '').strip()[:300]
            hint = stderr_hint or f'MpCmdRun.exe exited with code {res.returncode}.'
            if res.returncode == 13:
                hint = 'Windows Defender scan requires administrator privileges. Run VS Code as administrator or disable Defender scanning.'
            return {
                'enabled': True, 'files_scanned': 0, 'malicious': [],
                'clean': False, 'api_errors': 1,
                'error_message': f'Windows Defender scan error (exit {res.returncode}): {hint}'
            }
    except subprocess.TimeoutExpired:
        return {
            'enabled': True, 'files_scanned': 0, 'malicious': [],
            'clean': False, 'api_errors': 1,
            'error_message': 'Windows Defender scan timed out after 120 seconds.'
        }
    except Exception as e:
        return {
            'enabled': True, 'files_scanned': 0, 'malicious': [],
            'clean': False, 'api_errors': 1,
            'error_message': f'Windows Defender execution error: {e}'
        }

def scan_security(project_dir: str) -> dict:
    """
    Security scan. Reads SECURITY_ENGINE, VIRUSTOTAL_API_KEY + VIRUSTOTAL_ENABLED / SECURITY_SCAN_ENABLED from env.
    """
    engine = os.environ.get('SECURITY_ENGINE', 'VirusTotal').strip()
    scan_on = (os.environ.get('SECURITY_SCAN_ENABLED', '0').strip() == '1' or 
               os.environ.get('VIRUSTOTAL_ENABLED', '0').strip() == '1')

    if engine == 'WindowsDefender':
        if not scan_on:
            return {'enabled': False, 'files_scanned': 0, 'malicious': [], 'clean': True, 'api_errors': 0, 'error_message': '', 'engine': 'WindowsDefender'}
        print("[Zero-Trust Sandbox] Proactively scanning project directory with local Windows Defender...", file=sys.stderr, flush=True)
        r = _scan_with_defender(project_dir)
        r['engine'] = 'WindowsDefender'
        print(f"[Zero-Trust Sandbox] Windows Defender scan completed. Clean: {r['clean']}.", file=sys.stderr, flush=True)
        return r

    # VirusTotal requires enabling
    if not scan_on:
        return {'enabled': False, 'files_scanned': 0, 'malicious': [], 'clean': True, 'api_errors': 0, 'error_message': '', 'engine': 'VirusTotal'}

    print("[Zero-Trust Sandbox] Proactively scanning project files with VirusTotal...", file=sys.stderr, flush=True)
    api_key = os.environ.get('VIRUSTOTAL_API_KEY', '').strip()
    if not api_key:
        print("[Zero-Trust Sandbox] VirusTotal API Key is missing. Skipping file scan.", file=sys.stderr, flush=True)
        return {'enabled': False, 'files_scanned': 0, 'malicious': [], 'clean': True, 'api_errors': 0, 'error_message': ''}

    # ── Upfront API key validation ──
    # Use the empty-file SHA-256 hash for a lightweight test request.
    # This catches invalid keys BEFORE walking any files.
    empty_hash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
    try:
        test_req = urllib.request.Request(
            f'https://www.virustotal.com/api/v3/files/{empty_hash}',
            headers={'x-apikey': api_key},
        )
        urllib.request.urlopen(test_req, timeout=10)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            return {
                'enabled': True, 'files_scanned': 0, 'malicious': [],
                'clean': False, 'api_errors': 1,
                'error_message': f'Invalid or unauthorized API key (HTTP {e.code}). Check your VirusTotal API key.',
                'engine': 'VirusTotal'
            }
        elif e.code != 404:
            return {
                'enabled': True, 'files_scanned': 0, 'malicious': [],
                'clean': False, 'api_errors': 1,
                'error_message': f'VirusTotal API validation error (HTTP {e.code}).',
                'engine': 'VirusTotal'
            }
    except Exception as e:
        return {
            'enabled': True, 'files_scanned': 0, 'malicious': [],
            'clean': False, 'api_errors': 1,
            'error_message': f'VirusTotal connection error: {e}',
            'engine': 'VirusTotal'
        }

    files_scanned = 0
    malicious: list[str] = []
    api_errors = 0

    for root, dirs, files in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in (
            'node_modules', '__pycache__', '.underhood_libs', '.git',
            'venv', '.venv', 'env', 'dist', 'build', 'target'
        )]
        for filename in files:
            ext = os.path.splitext(filename)[1].lower()
            if ext not in VT_SCAN_EXTENSIONS:
                continue
            filepath = os.path.join(root, filename)
            try:
                data = open(filepath, 'rb').read()
            except OSError:
                continue
            sha256 = hashlib.sha256(data).hexdigest()
            files_scanned += 1
            try:
                req = urllib.request.Request(
                    f'https://www.virustotal.com/api/v3/files/{sha256}',
                    headers={'x-apikey': api_key},
                )
                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = json.loads(resp.read())
                    mc = (body.get('data', {})
                               .get('attributes', {})
                               .get('last_analysis_stats', {})
                               .get('malicious', 0))
                    if mc > 0:
                        malicious.append(filepath)
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    continue
                # For any other error (invalid key, rate limit, etc.), abort immediately
                api_errors += 1
                err_msg = f"VirusTotal API error (HTTP {e.code}). Check your VirusTotal API key."
                return {
                    'enabled': True,
                    'files_scanned': files_scanned,
                    'malicious': malicious,
                    'clean': False,
                    'api_errors': api_errors,
                    'error_message': err_msg,
                    'engine': 'VirusTotal'
                }
            except Exception as e:
                # Network or unexpected error - abort immediately
                api_errors += 1
                return {
                    'enabled': True,
                    'files_scanned': files_scanned,
                    'malicious': malicious,
                    'clean': False,
                    'api_errors': api_errors,
                    'error_message': f"VirusTotal connection or unexpected error: {e}",
                    'engine': 'VirusTotal'
                }

    is_clean = len(malicious) == 0 and api_errors == 0 and files_scanned > 0

    return {
        'enabled': True,
        'files_scanned': files_scanned,
        'malicious': malicious,
        'clean': is_clean,
        'api_errors': api_errors,
        'error_message': '',
        'engine': 'VirusTotal',
    }

class SecretsScanner:
    """
    Complex, well-structured secrets scan engine to catch credentials, tokens, PII, etc.
    """
    def __init__(self):
        import os
        import re
        self.enabled = os.environ.get('SECRETS_SCAN_ENABLED', '1').strip() == '1'
        self.ignore_dirs = {
            'node_modules', '.git', '__pycache__', '.underhood_libs',
            'venv', '.venv', 'env', 'dist', 'build', 'target', '.vscode', '.gemini'
        }
        self.ignore_extensions = {
            '.png', '.jpg', '.jpeg', '.gif', '.ico', '.webp', '.pdf', '.zip', '.tar.gz',
            '.exe', '.dll', '.so', '.dylib', '.lock', '.class', '.jar', '.war',
            '.woff', '.woff2', '.ttf', '.eot', '.mp3', '.mp4', '.wav', '.avi', '.mov',
            '.svg', '.import'
        }
        self.ignore_files = {
            'package-lock.json', 'yarn.lock', 'pnpm-lock.yaml', 'composer.lock',
            'poetry.lock', 'Gemfile.lock'
        }

        # Compile standard regex rules
        self.aws_re = re.compile(r'\b(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}\b')
        self.github_re = re.compile(r'\bgh[psoir]_[a-zA-Z0-9]{36,40}\b')
        self.stripe_live_re = re.compile(r'\bsk_live_[0-9a-zA-Z]{24}\b')
        self.conn_str_re = re.compile(r'\b(?:mongodb|postgres|postgresql|mysql|mssql|redis|sftp|ssh)://[^/\s:]+:[^/\s@]+@[^\s]+\b')
        self.private_key_re = re.compile(r'-----BEGIN [A-Z ]+ PRIVATE KEY-----')
        self.twilio_re = re.compile(r'\b(?:AC|SK)[0-9a-fA-F]{32}\b')

        self.stripe_test_re = re.compile(r'\bsk_test_[0-9a-zA-Z]{24}\b')
        self.google_api_re = re.compile(r'\bAIza[0-9A-Za-z\-_]{35}\b')
        self.slack_token_re = re.compile(r'\bxox[baprs]-[0-9a-zA-Z]{10,48}\b')
        self.jwt_re = re.compile(r'\beyJ[A-Za-z0-9-_=]+\.eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_+/=]+\b')
        
        # Generic secrets & passwords regex: matches both quoted and unquoted key-value assignments
        self.generic_secret_re = re.compile(
            r'(?:["\'])?\b(passwd|password|pwd|passphrase|api_key|apikey|secret_key|secret|token|access_key|auth_token|client_secret|private_key|credentials)\b(?:["\'])?\s*[:=]\s*["\']?([^"\'\r\n\s]{4,120})["\']?',
            re.IGNORECASE
        )
        
        self.email_re = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b')
        
        self.pii_assign_re = re.compile(
            r'(?:["\'])?\b(first_name|last_name|surname|ssn|phone_number|credit_card|card_number|card_num)\b(?:["\'])?\s*[:=]\s*["\']?([^"\'\r\n\s]{2,120})["\']?',
            re.IGNORECASE
        )
        self.phone_re = re.compile(r'\b(?:\+?\d{1,3}[-. ]?)?\(?\d{3}\)?[-. ]?\d{3}[-. ]?\d{4}\b')

    def is_binary(self, filepath: str) -> bool:
        try:
            with open(filepath, 'rb') as f:
                chunk = f.read(1024)
                if b'\x00' in chunk:
                    return True
        except Exception:
            return True
        return False

    def _validate_email(self, email: str) -> bool:
        return not any(domain in email.lower() for domain in ['example.com', 'placeholder.com', 'test.com'])

    def scan(self, project_dir: str) -> dict:
        if not self.enabled:
            return {
                'enabled': False,
                'files_scanned': 0,
                'total': 0,
                'counts': {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0},
                'findings': []
            }

        files_scanned = 0
        total = 0
        counts = {'CRITICAL': 0, 'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        findings = []

        def redact(val: str) -> str:
            val = val.strip()
            if len(val) <= 6:
                return val[:min(len(val), 3)] + "***REDACTED***"
            return val[:6] + "***REDACTED***"

        # Walk directories
        for root, dirs, files in os.walk(project_dir):
            # Prune ignored directories in-place
            dirs[:] = [d for d in dirs if d not in self.ignore_dirs and not d.startswith('.')]
            for file in files:
                if file in self.ignore_files or (file.startswith('.') and file != '.env'):
                    continue
                ext = os.path.splitext(file)[1].lower()
                if ext in self.ignore_extensions:
                    continue
                
                filepath = os.path.join(root, file)
                if self.is_binary(filepath):
                    continue
                
                relpath = os.path.relpath(filepath, project_dir)
                files_scanned += 1
                
                # Read and scan file
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()
                except Exception:
                    continue
                
                is_env_file = (file == '.env' or file.endswith('.env') or 'env' in file.lower())
                
                for line_idx, line in enumerate(lines, 1):
                    clean_line = line.strip()
                    if not clean_line or clean_line.startswith('#') or clean_line.startswith('//') or clean_line.startswith(';'):
                        continue
                    
                    matched_vals = set()

                    # 1. CRITICAL checks
                    # AWS
                    for m in self.aws_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'AWS API Key',
                            'severity': 'CRITICAL', 'preview': redact(m)
                        })
                        counts['CRITICAL'] += 1
                        total += 1
                    
                    # GitHub Token
                    for m in self.github_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'GitHub Token',
                            'severity': 'CRITICAL', 'preview': redact(m)
                        })
                        counts['CRITICAL'] += 1
                        total += 1

                    # Stripe Live Key
                    for m in self.stripe_live_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Stripe Secret Key',
                            'severity': 'CRITICAL', 'preview': redact(m)
                        })
                        counts['CRITICAL'] += 1
                        total += 1

                    # Connection string with credentials
                    for m in self.conn_str_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Connection String',
                            'severity': 'CRITICAL', 'preview': redact(m)
                        })
                        counts['CRITICAL'] += 1
                        total += 1

                    # Twilio SID
                    for m in self.twilio_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Twilio Account SID',
                            'severity': 'CRITICAL', 'preview': redact(m)
                        })
                        counts['CRITICAL'] += 1
                        total += 1

                    # Private Key
                    if self.private_key_re.search(line):
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Private Key',
                            'severity': 'CRITICAL', 'preview': '-----BEGIN ***REDACTED*** PRIVATE KEY-----'
                        })
                        counts['CRITICAL'] += 1
                        total += 1

                    # 2. HIGH checks
                    # Stripe Test Key
                    for m in self.stripe_test_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Stripe Test Key',
                            'severity': 'HIGH', 'preview': redact(m)
                        })
                        counts['HIGH'] += 1
                        total += 1

                    # Google API Key
                    for m in self.google_api_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Google API Key',
                            'severity': 'HIGH', 'preview': redact(m)
                        })
                        counts['HIGH'] += 1
                        total += 1

                    # Slack Token
                    for m in self.slack_token_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'Slack Token',
                            'severity': 'HIGH', 'preview': redact(m)
                        })
                        counts['HIGH'] += 1
                        total += 1

                    # JWT Token
                    for m in self.jwt_re.findall(line):
                        matched_vals.add(m)
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'JWT Token',
                            'severity': 'HIGH', 'preview': redact(m)
                        })
                        counts['HIGH'] += 1
                        total += 1

                    # Env file check (key = value)
                    if is_env_file:
                        env_match = re.match(r'^([a-zA-Z_0-9]+)\s*=\s*(.+)$', clean_line)
                        if env_match:
                            key, val = env_match.group(1), env_match.group(2).strip('"\'-')
                            if val and val not in matched_vals:
                                sensitive_words = {'KEY', 'SECRET', 'PASS', 'TOKEN', 'CRED', 'AUTH', 'DB', 'USER', 'PWD', 'API', 'JWT', 'PRIVATE'}
                                if any(w in key.upper() for w in sensitive_words):
                                    val_upper = val.upper()
                                    if val_upper not in ('TRUE', 'FALSE', 'NULL', 'NONE', 'NIL', 'UNDEFINED'):
                                        matched_vals.add(val)
                                        findings.append({
                                            'file': relpath, 'line': line_idx, 'category': 'Environment Secret',
                                            'severity': 'HIGH', 'preview': redact(val)
                                        })
                                        counts['HIGH'] += 1
                                        total += 1

                    # Generic secret assignment in code files
                    for key, val in self.generic_secret_re.findall(line):
                        val_strip = val.strip('"\'-')
                        if val_strip and val_strip not in matched_vals:
                            val_upper = val_strip.upper()
                            # Filter out booleans, nulls, placeholders
                            if val_upper in ('TRUE', 'FALSE', 'NULL', 'NONE', 'NIL', 'UNDEFINED', 'VOID', 'EMPTY', 'DEFAULT', 'PLACEHOLDER', 'EXAMPLE', 'TEST', 'DUMMY'):
                                continue
                            # Filter out Godot UIDs, resource links, and colors
                            if val_strip.startswith('uid://') or val_strip.startswith('res://') or val_strip.startswith('Color('):
                                continue
                            # Filter out numeric dimensions / indices / float formats if not all numeric password
                            if re.match(r'^-?\d+(?:\.\d+)?$', val_strip) and len(val_strip) < 4:
                                continue
                            # Filter out common CSS/SVG/hex colors
                            if val_strip.startswith('#') and len(val_strip) in (4, 7, 9):
                                continue
                            # Filter out local file paths
                            if val_strip.startswith('/') or val_strip.startswith('./') or val_strip.startswith('../') or (len(val_strip) > 2 and val_strip[1] == ':'):
                                continue
                            
                            matched_vals.add(val_strip)
                            findings.append({
                                'file': relpath, 'line': line_idx, 'category': 'API Key / Credentials',
                                'severity': 'HIGH', 'preview': redact(val_strip)
                            })
                            counts['HIGH'] += 1
                            total += 1

                    # 3. MEDIUM checks
                    # Email
                    emails = self.email_re.findall(line)
                    for email in emails:
                        if email not in matched_vals:
                            if self._validate_email(email):
                                matched_vals.add(email)
                                findings.append({
                                    'file': relpath, 'line': line_idx, 'category': 'PII (Email)',
                                    'severity': 'MEDIUM', 'preview': redact(email)
                                })
                                counts['MEDIUM'] += 1
                                total += 1

                    # 4. LOW checks
                    # Personal Info
                    for key, val in self.pii_assign_re.findall(line):
                        val_strip = val.strip('"\'-')
                        val_upper = val_strip.upper()
                        if val_upper in ('TRUE', 'FALSE', 'NULL', 'NONE', 'NIL', 'UNDEFINED'):
                            continue
                        if val_strip.startswith('uid://') or val_strip.startswith('res://'):
                            continue
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'PII (Personal Details)',
                            'severity': 'LOW', 'preview': redact(val_strip)
                        })
                        counts['LOW'] += 1
                        total += 1

                    # Phone number
                    for m in self.phone_re.findall(line):
                        findings.append({
                            'file': relpath, 'line': line_idx, 'category': 'PII (Phone Number)',
                            'severity': 'LOW', 'preview': redact(m)
                        })
                        counts['LOW'] += 1
                        total += 1

        return {
            'enabled': True,
            'files_scanned': files_scanned,
            'total': total,
            'counts': counts,
            'findings': findings
        }

def scan_secrets(project_dir: str) -> dict:
    scanner = SecretsScanner()
    return scanner.scan(project_dir)


# ── Security exception ──────────────────────────────────────────────────────────

class SecurityAlertException(Exception):
    pass


# ── LLM connectors (kept for future use) ─────────────────────────────────────

class LLMConnector:
    """Abstract base class for LLM debugging engines."""
    async def analyze_error(self, error_message: str) -> str:
        raise NotImplementedError("Subclasses must implement analyze_error")


class CloudLLMConnector(LLMConnector):
    def __init__(self, api_key: str):
        self.api_key = api_key

    async def analyze_error(self, error_message: str) -> str:
        return f"Cloud LLM analyzed: {error_message}"


class LocalLLMConnector(LLMConnector):
    def __init__(self, endpoint_url: str):
        self.endpoint_url = endpoint_url

    async def analyze_error(self, error_message: str) -> str:
        return f"Local LLM analyzed: {error_message}"


# ── Stdlib allowlists ─────────────────────────────────────────────────────────

PYTHON_STDLIB = set(sys.stdlib_module_names) if hasattr(sys, 'stdlib_module_names') else {
    'os', 'sys', 're', 'json', 'math', 'time', 'datetime', 'pathlib', 'io',
    'collections', 'itertools', 'functools', 'typing', 'abc', 'copy',
    'hashlib', 'base64', 'struct', 'socket', 'ssl', 'http', 'urllib',
    'csv', 'sqlite3', 'logging', 'unittest', 'threading', 'subprocess',
    'shutil', 'tempfile', 'glob', 'asyncio', 'concurrent', 'contextlib',
    'dataclasses', 'enum', 'uuid', 'random', 'string', 'pprint', 'decimal',
    'queue', 'heapq', 'weakref', 'platform', 'importlib', 'zipfile', 'pickle',
    'configparser', 'argparse', 'codecs', 'traceback', 'warnings', 'inspect',
    'ast', 'gc', 'signal', 'errno', 'stat', 'builtins',
}

NODE_BUILTIN = {
    'fs', 'path', 'os', 'http', 'https', 'url', 'crypto', 'events',
    'stream', 'buffer', 'util', 'net', 'dns', 'child_process', 'cluster',
    'readline', 'assert', 'vm', 'module', 'process', 'timers', 'console',
    'querystring', 'zlib', 'tls', 'dgram', 'worker_threads',
}


# ── Canonical Import-to-Package Mapping (anti-dependency-confusion) ───────────

IMPORT_ALIAS_MAP = {
    "cv2": "opencv-python",
    "PIL": "Pillow",
    "yaml": "PyYAML",
    "bs4": "beautifulsoup4",
    "sklearn": "scikit-learn",
    "dotenv": "python-dotenv",
    "jwt": "PyJWT",
    "fitz": "PyMuPDF",
    "Crypto": "pycryptodome",
    "serial": "pyserial",
    "dateutil": "python-dateutil",
    "usb": "pyusb",
    "wx": "wxPython",
    "gi": "PyGObject",
    "magic": "python-magic",
    "git": "GitPython",
    "psycopg2": "psycopg2-binary",
    "MySQLdb": "mysqlclient",
    "OpenSSL": "pyOpenSSL",
    "attr": "attrs",
    "websocket": "websocket-client",
    "dns": "dnspython",
    "paramiko": "paramiko",
    "playwright": "playwright",
    "selenium": "selenium",
}

def is_local_module(directory: str, pkg_name: str, runtime: str) -> bool:
    """Returns True if pkg_name corresponds to a local file/folder inside the workspace."""
    if not pkg_name or not directory:
        return False
    d = Path(directory)
    if not d.is_dir():
        return False
    clean = pkg_name.strip().split('/')[0].split('.')[0]
    if runtime == 'python':
        candidates = [
            d / f"{clean}.py",
            d / clean / "__init__.py",
            d / "src" / f"{clean}.py",
            d / "src" / clean / "__init__.py",
        ]
        return any(c.exists() for c in candidates)
    elif runtime in ('node', 'typescript'):
        candidates = [
            d / f"{clean}.js",
            d / f"{clean}.ts",
            d / f"{clean}.jsx",
            d / f"{clean}.tsx",
            d / clean / "index.js",
            d / clean / "index.ts",
            d / "src" / f"{clean}.js",
            d / "src" / f"{clean}.ts",
        ]
        return any(c.exists() for c in candidates)
    elif runtime == 'lua':
        candidates = [
            d / f"{clean}.lua",
            d / clean / "init.lua",
        ]
        return any(c.exists() for c in candidates)
    elif runtime == 'ruby':
        candidates = [
            d / f"{clean}.rb",
            d / "lib" / f"{clean}.rb",
        ]
        return any(c.exists() for c in candidates)
    elif runtime == 'powershell':
        candidates = [
            d / f"{clean}.ps1",
            d / f"{clean}.psm1",
            d / f"{clean}.psd1",
        ]
        return any(c.exists() for c in candidates)
    return False

def load_lockfile(directory: str) -> dict | None:
    """Reads and parses .underhood/underhood.lock.json if it exists."""
    try:
        lock_path = os.path.join(directory, ".underhood", "underhood.lock.json")
        if os.path.isfile(lock_path):
            with open(lock_path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return None

def save_lockfile(directory: str, runtime: str, dep_report: list[dict]):
    """Persists resolved and installed dependencies into .underhood/underhood.lock.json."""
    try:
        underhood_dir = os.path.join(directory, ".underhood")
        os.makedirs(underhood_dir, exist_ok=True)
        lock_path = os.path.join(underhood_dir, "underhood.lock.json")
        now_iso = datetime.datetime.now(datetime.timezone.utc).isoformat()
        lock_data = {
            "version": "1.0",
            "updated_at": now_iso,
            "runtime": runtime,
            "packages": {}
        }
        if os.path.exists(lock_path):
            try:
                with open(lock_path, "r", encoding="utf-8") as f:
                    existing = json.load(f)
                    if isinstance(existing, dict) and "packages" in existing:
                        lock_data["packages"] = existing["packages"]
            except Exception:
                pass
        for dep in dep_report:
            name = dep.get("name")
            if not name:
                continue
            lock_data["packages"][name] = {
                "status": dep.get("status", "installed"),
                "safety": dep.get("safety", "Safe"),
                "updated_at": now_iso
            }
        with open(lock_path, "w", encoding="utf-8") as f:
            json.dump(lock_data, f, indent=2)
    except Exception as e:
        print(f"[Underhood Lockfile] Warning: could not save lockfile: {e}", file=sys.stderr)

def clean_sandbox(directory: str) -> list[str]:
    """Removes local sandbox folders (.underhood_libs, lua_modules, .underhood_gems, .underhood_psmodules)."""
    import shutil
    cleaned = []
    targets = [".underhood_libs", "lua_modules", ".underhood_gems", ".underhood_psmodules"]
    for t in targets:
        p = os.path.join(directory, t)
        if os.path.isdir(p):
            shutil.rmtree(p, ignore_errors=True)
            cleaned.append(t)
    return cleaned

def clean_cache() -> int:
    """Clears ~/.underhood/cache and returns number of files removed."""
    cache_dir = os.path.join(os.path.expanduser("~"), ".underhood", "cache")
    count = 0
    if os.path.isdir(cache_dir):
        for root, dirs, files in os.walk(cache_dir):
            for file in files:
                try:
                    os.remove(os.path.join(root, file))
                    count += 1
                except Exception:
                    pass
    return count

def export_manifest(directory: str, runtime: str) -> str:
    """Exports discovered dependencies to requirements.txt or package.json."""
    underhood_dir = os.path.join(directory, ".underhood")
    lock_path = os.path.join(underhood_dir, "underhood.lock.json")
    packages = []
    if os.path.isfile(lock_path):
        try:
            with open(lock_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                packages = list(data.get("packages", {}).keys())
        except Exception:
            pass
    if not packages:
        runner = UnderhoodRunner(directory)
        packages = runner.scan_imports(directory, runtime)

    if runtime == "python":
        req_path = os.path.join(directory, "requirements.txt")
        existing_lines = []
        if os.path.isfile(req_path):
            with open(req_path, "r", encoding="utf-8") as f:
                existing_lines = [l.strip() for l in f if l.strip() and not l.startswith('#')]
        combined = sorted(set(existing_lines + packages))
        with open(req_path, "w", encoding="utf-8") as f:
            f.write("\n".join(combined) + "\n")
        return req_path
    elif runtime in ("node", "typescript"):
        pkg_json_path = os.path.join(directory, "package.json")
        pkg_data = {}
        if os.path.isfile(pkg_json_path):
            try:
                with open(pkg_json_path, "r", encoding="utf-8") as f:
                    pkg_data = json.load(f)
            except Exception:
                pkg_data = {}
        if "dependencies" not in pkg_data:
            pkg_data["dependencies"] = {}
        for p in packages:
            if p not in pkg_data["dependencies"]:
                pkg_data["dependencies"][p] = "*"
        with open(pkg_json_path, "w", encoding="utf-8") as f:
            json.dump(pkg_data, f, indent=2)
        return pkg_json_path
    return ""

def scan_with_virustotal(project_dir: str) -> dict:
    """Backward-compatible alias for scan_security forcing VirusTotal."""
    old_engine = os.environ.get('SECURITY_ENGINE')
    os.environ['SECURITY_ENGINE'] = 'VirusTotal'
    try:
        return scan_security(project_dir)
    finally:
        if old_engine is not None:
            os.environ['SECURITY_ENGINE'] = old_engine
        else:
            os.environ.pop('SECURITY_ENGINE', None)

# ── UnderhoodRunner (Universal Execution Engine) ──────────────────────────────

class UnderhoodRunner:
    """
    Handles runtime execution for Python, Node.js, and Lua projects.
    Used only when the project type is one of those three.
    """

    def __init__(self, directory: str, llm_connector: LLMConnector = None):
        self.directory = directory
        self.max_retries = 5
        self.llm_connector = llm_connector

    async def run_with_repair(self, script_name: str) -> dict:
        runtime = self.determine_runtime()

        # Proactive: scan imports and install missing ones
        imports = self.scan_imports(self.directory, runtime)
        dep_report = []
        for pkg in imports:
            installed = await self.check_installed(pkg, runtime)
            dep_report.append({
                "name":   pkg,
                "status": "installed" if installed else "missing",
            })
            if not installed:
                ok = await self.install_dependency(pkg, runtime)
                for entry in dep_report:
                    if entry["name"] == pkg:
                        entry["status"] = "installed (auto)" if ok else "failed to install"

        exec_result = await self.execute(script_name)
        exec_result["dep_report"] = dep_report
        save_lockfile(self.directory, runtime, dep_report)
        return exec_result

    # ── Import scanner ────────────────────────────────────────────────────────

    def scan_imports(self, directory: str, runtime: str) -> list[str]:
        found = set()
        extensions = {
            'python': ('.py',),
            'node':   ('.js', '.jsx', '.mjs', '.cjs'),
            'typescript': ('.ts', '.tsx', '.mts', '.cts'),
            'lua':    ('.lua',),
            'go':     ('.go',),
            'rust':   ('.rs',),
            'dotnet': ('.cs',),
            'ruby':   ('.rb',),
            'php':    ('.php',),
            'powershell': ('.ps1', '.psm1'),
        }.get(runtime, ('.py',))

        for root, dirs, files in os.walk(directory):
            dirs[:] = [
                d for d in dirs
                if not d.startswith('.')
                and d not in ('node_modules', '__pycache__', '.underhood_libs',
                              'lua_modules', '.underhood_gems', '.underhood_psmodules',
                              'venv', '.venv', 'env', 'dist', 'build', 'target', 'bin', 'obj')
            ]
            for filename in files:
                if not filename.endswith(extensions):
                    continue
                filepath = os.path.join(root, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as fh:
                        found.update(self._extract_imports(fh.read(), runtime))
                except OSError:
                    pass

        cleaned = set()
        for pkg in found:
            if is_local_module(directory, pkg, runtime):
                continue
            if runtime == 'python':
                top = pkg.split('.')[0]
                if not top or top in PYTHON_STDLIB:
                    continue
                mapped = IMPORT_ALIAS_MAP.get(top, top)
                if re.match(r'^[\w\-\.]+$', mapped):
                    cleaned.add(mapped)
            elif runtime in ('node', 'typescript'):
                if pkg.startswith('.'):
                    continue
                if pkg.startswith('@'):
                    parts = pkg.split('/')
                    top = '/'.join(parts[:2]) if len(parts) >= 2 else pkg
                else:
                    top = pkg.split('/')[0]
                if not top or top in NODE_BUILTIN:
                    continue
                if re.match(r'^@?[\w\-\./]+$', top):
                    cleaned.add(top)
            else:
                if re.match(r'^[\w\-\./]+$', pkg):
                    cleaned.add(pkg)

        return sorted(cleaned)

    def _extract_imports(self, source: str, runtime: str) -> list[str]:
        imports = []
        if runtime == 'python':
            for m in re.finditer(r'^\s*(?:import|from)\s+([\w\.]+)', source, re.MULTILINE):
                imports.append(m.group(1))
        elif runtime == 'node':
            for m in re.finditer(r'require\(["\']([^"\']+)["\']\)', source):
                imports.append(m.group(1))
            for m in re.finditer(
                r'^\s*import\s+(?:.*\s+from\s+)?["\']([^"\']+)["\']',
                source, re.MULTILINE
            ):
                imports.append(m.group(1))
        elif runtime == 'lua':
            for m in re.finditer(r'require\(["\']([^"\']+)["\']\)', source):
                imports.append(m.group(1))
        return imports

    # ── Installed-package checker ─────────────────────────────────────────────

    async def check_installed(self, pkg: str, runtime: str) -> bool:
        if runtime == 'python':
            underhood_libs = os.path.join(self.directory, '.underhood_libs')
            if os.path.isdir(underhood_libs):
                clean_p = pkg.replace('-', '_').lower()
                for entry in os.listdir(underhood_libs):
                    entry_clean = entry.lower().replace('-', '_').split('.')[0]
                    if entry_clean == clean_p or entry.lower().startswith(f"{clean_p}-") or entry.lower().startswith(f"{clean_p}."):
                        return True
            if importlib.util.find_spec(pkg.replace('-', '_')) is not None:
                return True
            proc = await asyncio.create_subprocess_exec(
                PYTHON_EXE, '-m', 'pip', 'show', pkg,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.communicate()
            return proc.returncode == 0
        elif runtime in ('node', 'typescript'):
            node_modules = os.path.join(self.directory, 'node_modules')
            if os.path.isdir(node_modules):
                pkg_dir = os.path.join(node_modules, *pkg.split('/'))
                if os.path.isdir(pkg_dir):
                    return True
            proc = await asyncio.create_subprocess_exec(
                'npm', 'ls', pkg, '--depth=0',
                cwd=self.directory,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.communicate()
            return proc.returncode == 0
        elif runtime == 'lua':
            lua_modules = os.path.join(self.directory, 'lua_modules')
            if os.path.isdir(lua_modules):
                for root, dirs, files in os.walk(lua_modules):
                    if any(f.startswith(pkg) for f in files) or any(d == pkg for d in dirs):
                        return True
            proc = await asyncio.create_subprocess_exec(
                'luarocks', 'show', pkg,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await proc.communicate()
            return proc.returncode == 0
        elif runtime == 'ruby':
            gems_dir = os.path.join(self.directory, '.underhood_gems', 'gems')
            if os.path.isdir(gems_dir):
                if any(d.startswith(pkg) for d in os.listdir(gems_dir)):
                    return True
            return False
        elif runtime == 'powershell':
            ps_dir = os.path.join(self.directory, '.underhood_psmodules', pkg)
            return os.path.isdir(ps_dir)
        elif runtime in ('go', 'rust', 'dotnet', 'php'):
            return False
        return False

    # ── Script executor ───────────────────────────────────────────────────────

    async def execute(self, script_name: str) -> dict:
        import shutil
        runtime = self.determine_runtime()
        retries = 0

        use_sandbox = os.environ.get('UNDERHOOD_SANDBOX') == '1'
        if use_sandbox:
            if not shutil.which("docker"):
                return {
                    'returncode': 1,
                    'stdout': '',
                    'stderr': "Docker is required for Isolated Sandbox Execution, but was not found in PATH.",
                    'dep_report': []
                }

        env = os.environ.copy()
        if runtime == 'python':
            underhood_libs = os.path.join(self.directory, '.underhood_libs')
            env['PYTHONPATH'] = underhood_libs + os.pathsep + env.get('PYTHONPATH', '')
        elif runtime in ('node', 'typescript'):
            node_modules = os.path.join(self.directory, 'node_modules')
            env['NODE_PATH'] = node_modules + os.pathsep + env.get('NODE_PATH', '')
            env['PATH'] = os.path.join(node_modules, '.bin') + os.pathsep + env.get('PATH', '')
        elif runtime == 'lua':
            lua_modules = os.path.join(self.directory, 'lua_modules')
            env['LUA_PATH'] = f"{lua_modules}/share/lua/5.4/?.lua;{lua_modules}/share/lua/5.4/?/init.lua;" + env.get('LUA_PATH', ';')
            env['LUA_CPATH'] = f"{lua_modules}/lib/lua/5.4/?.so;{lua_modules}/lib/lua/5.4/?.dll;" + env.get('LUA_CPATH', ';')
        elif runtime == 'ruby':
            gem_dir = os.path.join(self.directory, '.underhood_gems')
            env['GEM_HOME'] = gem_dir
            env['GEM_PATH'] = gem_dir
            env['PATH'] = os.path.join(gem_dir, 'bin') + os.pathsep + env.get('PATH', '')
        elif runtime == 'powershell':
            ps_dir = os.path.join(self.directory, '.underhood_psmodules')
            env['PSModulePath'] = ps_dir + os.pathsep + env.get('PSModulePath', '')

        while retries < self.max_retries:
            if use_sandbox:
                abs_dir = os.path.abspath(self.directory)
                if runtime == 'python':
                    cmd = ["docker", "run", "--rm", "-v", f"{abs_dir}:/workspace", "-w", "/workspace", "-e", "PYTHONPATH=/workspace/.underhood_libs", "python:3.11-slim", "python", script_name]
                elif runtime in ('node', 'typescript'):
                    cmd = ["docker", "run", "--rm", "-v", f"{abs_dir}:/workspace", "-w", "/workspace", "node:20-slim", "node", script_name]
                elif runtime == 'lua':
                    cmd = ["docker", "run", "--rm", "-v", f"{abs_dir}:/workspace", "-w", "/workspace", "akorn/lua:5.4-alpine", "lua", script_name]
                else:
                    raise ValueError(f"Unsupported sandbox runtime: {runtime}")
            else:
                if runtime == 'python':
                    cmd = [PYTHON_EXE, script_name]
                elif runtime == 'node':
                    cmd = ["node", script_name]
                elif runtime == 'typescript':
                    if shutil.which("bun"):
                        cmd = ["bun", "run", script_name]
                    elif shutil.which("deno"):
                        cmd = ["deno", "run", "-A", script_name]
                    elif shutil.which("tsx"):
                        cmd = ["tsx", script_name]
                    elif shutil.which("npx"):
                        cmd = ["npx", "tsx", script_name]
                    else:
                        cmd = ["node", script_name]
                elif runtime == 'lua':
                    cmd = ["lua", script_name]
                elif runtime == 'go':
                    cmd = ["go", "run", script_name if script_name.endswith('.go') else "."]
                elif runtime == 'rust':
                    cmd = ["cargo", "run"]
                elif runtime == 'dotnet':
                    cmd = ["dotnet", "run"]
                elif runtime == 'ruby':
                    cmd = ["ruby", script_name]
                elif runtime == 'php':
                    cmd = ["php", script_name]
                elif runtime == 'powershell':
                    pwsh_bin = "pwsh" if shutil.which("pwsh") else "powershell"
                    cmd = [pwsh_bin, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script_name]
                else:
                    raise ValueError(f"Unsupported runtime: {runtime}")

            process = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=self.directory,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            stdout_bytes, stderr_bytes = await process.communicate()
            stdout = stdout_bytes.decode() if stdout_bytes else ''
            stderr = stderr_bytes.decode() if stderr_bytes else ''

            if process.returncode != 0:
                try:
                    missing_pkg = self.extract_missing_dependency(stderr, runtime)
                    if missing_pkg:
                        success = await self.install_dependency(missing_pkg, runtime)
                        if success:
                            retries += 1
                            continue
                except SecurityAlertException as e:
                    return {'returncode': -1, 'stdout': stdout, 'stderr': str(e), 'dep_report': []}

            return {'returncode': process.returncode, 'stdout': stdout, 'stderr': stderr, 'dep_report': []}

        return {
            'returncode': process.returncode,
            'stdout': stdout,
            'stderr': f"Max retries reached. Last error: {stderr}",
            'dep_report': [],
        }

    # ── Security-validated dependency extractor ───────────────────────────────

    def extract_missing_dependency(self, stderr: str, runtime: str) -> str | None:
        pkg_name = None
        if runtime == 'python':
            m = re.search(r"ModuleNotFoundError: No module named '([^']+)'", stderr)
            if not m:
                m = re.search(r"ImportError: No module named '([^']+)'", stderr)
            if not m:
                m = re.search(r"ImportError: cannot import name '[^']+' from '([^']+)'", stderr)
            if m:
                raw_pkg = m.group(1)
                if raw_pkg in IMPORT_ALIAS_MAP:
                    pkg_name = IMPORT_ALIAS_MAP[raw_pkg]
                elif raw_pkg.split('.')[0] in IMPORT_ALIAS_MAP:
                    pkg_name = IMPORT_ALIAS_MAP[raw_pkg.split('.')[0]]
                else:
                    pkg_name = raw_pkg
        elif runtime in ('node', 'typescript'):
            m = re.search(r"(?:Error:\s*)?Cannot find module '([^']+)'", stderr)
            if not m:
                m = re.search(r"Cannot find package '([^']+)'", stderr)
            if not m:
                m = re.search(r"ERR_MODULE_NOT_FOUND.*'([^']+)'", stderr)
            if m:
                candidate = m.group(1)
                if candidate.startswith('@'):
                    parts = candidate.split('/')
                    pkg_name = '/'.join(parts[:2]) if len(parts) >= 2 else candidate
                else:
                    pkg_name = candidate.split('/')[0]
        elif runtime == 'lua':
            m = re.search(r"module '([^']+)' not found:", stderr)
            if m:
                pkg_name = m.group(1)
        elif runtime == 'go':
            m = re.search(r"no required module provides package ([^\s;]+)", stderr)
            if not m:
                m = re.search(r"missing go\.sum entry for module providing package ([^\s;]+)", stderr)
            if m:
                pkg_name = m.group(1)
        elif runtime == 'rust':
            m = re.search(r"error\[E0432\]: unresolved import `?([a-zA-Z0-9_]+)", stderr)
            if not m:
                m = re.search(r"can't find crate for `?([a-zA-Z0-9_]+)", stderr)
            if m:
                pkg_name = m.group(1)
        elif runtime == 'dotnet':
            m = re.search(r"error CS0246: The type or namespace name '([^']+)' could not be found", stderr)
            if not m:
                m = re.search(r"error NU1101: Unable to find package ([^\s\.]+)", stderr)
            if m:
                pkg_name = m.group(1)
        elif runtime == 'ruby':
            m = re.search(r"cannot load such file -- ([^\s(]+) \(LoadError\)", stderr)
            if m:
                pkg_name = m.group(1).split('/')[0]
        elif runtime == 'php':
            m = re.search(r"Class ['\"]([^'\"]+)['\"] not found", stderr)
            if not m:
                m = re.search(r"Failed opening required '([^']+)'", stderr)
            if m:
                pkg_name = m.group(1).split('\\')[0].lower()
        elif runtime == 'powershell':
            m = re.search(r"The specified module '([^']+)' was not loaded", stderr)
            if not m:
                m = re.search(r"The term '([^']+)' is not recognized", stderr)
            if m:
                pkg_name = m.group(1)

        if pkg_name:
            blocklist = [';', '&&', '||', '|', '$', '`', '>', '<', '\n', '\r', '\0']
            if any(op in pkg_name for op in blocklist) or '..' in pkg_name:
                raise SecurityAlertException(
                    f"CRITICAL SECURITY ALERT: Shell injection attempt in package name: {pkg_name}"
                )
            if runtime == 'python':
                if not re.match(r'^[\w\-\.]+$', pkg_name) or '/' in pkg_name or '\\' in pkg_name:
                    raise SecurityAlertException(
                        f"CRITICAL SECURITY ALERT: Invalid characters in package name: {pkg_name}"
                    )
            elif runtime in ('node', 'typescript'):
                if pkg_name.startswith('@'):
                    if not re.match(r'^@[a-zA-Z0-9_\-]+\/[a-zA-Z0-9_\-\.]+$', pkg_name):
                        raise SecurityAlertException(
                            f"CRITICAL SECURITY ALERT: Invalid characters in package name: {pkg_name}"
                        )
                else:
                    if not re.match(r'^[a-zA-Z0-9_\-\.]+$', pkg_name):
                        raise SecurityAlertException(
                            f"CRITICAL SECURITY ALERT: Invalid characters in package name: {pkg_name}"
                        )
            elif runtime == 'go':
                if not re.match(r'^[a-zA-Z0-9_\-\./]+$', pkg_name):
                    raise SecurityAlertException(
                        f"CRITICAL SECURITY ALERT: Invalid characters in package name: {pkg_name}"
                    )
            else:
                if not re.match(r'^[a-zA-Z0-9_\-\.]+$', pkg_name):
                    raise SecurityAlertException(
                        f"CRITICAL SECURITY ALERT: Invalid characters in package name: {pkg_name}"
                    )
            return pkg_name
        return None

    def is_compatible_wheel(self, filename: str) -> bool:
        if not filename.endswith('.whl'):
            return False
        parts = filename[:-4].split('-')
        if len(parts) < 5:
            return False
        platform_tag = parts[-1]
        py_tag = parts[-3]
        
        py_ver = f"cp{sys.version_info.major}{sys.version_info.minor}"
        is_py3 = 'py3-none-any' in filename or 'py2.py3-none-any' in filename or 'py3-none' in py_tag
        if not is_py3 and py_ver not in py_tag:
            return False
            
        if 'any' in platform_tag:
            return True
            
        if sys.platform == 'win32':
            if 'win_amd64' in platform_tag and sys.maxsize > 2**32:
                return True
            if 'win32' in platform_tag and sys.maxsize <= 2**32:
                return True
        elif sys.platform == 'darwin':
            if 'macosx' in platform_tag:
                import platform
                arch = platform.machine().lower()
                if 'arm64' in platform_tag and ('arm' in arch or 'aarch' in arch):
                    return True
                if 'x86_64' in platform_tag and 'x86_64' in arch:
                    return True
        else: # linux
            if 'manylinux' in platform_tag or 'linux' in platform_tag:
                import platform
                arch = platform.machine().lower()
                if 'x86_64' in platform_tag and ('x86_64' in arch or 'amd64' in arch):
                    return True
                if 'aarch64' in platform_tag and ('arm' in arch or 'aarch' in arch):
                    return True
        return False

    def fetch_pypi_whl_url(self, pkg: str) -> str | None:
        try:
            url = f"https://pypi.org/pypi/{pkg}/json"
            req = urllib.request.Request(url, headers={'User-Agent': 'Underhood/1.0'})
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                urls = data.get('urls', [])
                whl_url = None
                sdist_url = None
                for u in urls:
                    filename = u.get('filename', '')
                    if self.is_compatible_wheel(filename):
                        return u.get('url')
                    elif filename.endswith('.whl'):
                        whl_url = u.get('url')
                    elif filename.endswith('.tar.gz'):
                        sdist_url = u.get('url')
                return whl_url or sdist_url
        except Exception as e:
            print(f"Error fetching PyPI metadata for {pkg}: {e}", file=sys.stderr)
            return None

    def fetch_npm_tarball_url(self, pkg: str) -> str | None:
        try:
            encoded_pkg = pkg.replace('/', '%2F')
            url = f"https://registry.npmjs.org/{encoded_pkg}"
            req = urllib.request.Request(url, headers={'User-Agent': 'Underhood/1.0'})
            with urllib.request.urlopen(req, timeout=10) as response:
                data = json.loads(response.read().decode('utf-8'))
                dist_tags = data.get('dist-tags', {})
                latest_version = dist_tags.get('latest')
                if latest_version:
                    version_info = data.get('versions', {}).get(latest_version, {})
                    return version_info.get('dist', {}).get('tarball')
        except Exception as e:
            print(f"Error fetching NPM metadata for {pkg}: {e}", file=sys.stderr)
            return None

    def _download_file_sync(self, url: str, dest_path: str, package_name: str):
        import time
        req = urllib.request.Request(url, headers={'User-Agent': 'Underhood/1.0'})
        with urllib.request.urlopen(req, timeout=15) as response:
            total_size = int(response.info().get('Content-Length', 0))
            downloaded = 0
            chunk_size = 65536
            start_time = time.time()
            
            with open(dest_path, 'wb') as f:
                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    
                    percent = int(downloaded * 100 / total_size) if total_size > 0 else 0
                    elapsed = time.time() - start_time
                    speed = downloaded / elapsed if elapsed > 0 else 0
                    if speed > 1024 * 1024:
                        speed_str = f"{speed / (1024 * 1024):.2f} MB/s"
                    elif speed > 1024:
                        speed_str = f"{speed / 1024:.2f} KB/s"
                    else:
                        speed_str = f"{speed:.2f} B/s"
                        
                    progress_msg = {
                        "type": "download_progress",
                        "package": package_name,
                        "percent": percent,
                        "speed": speed_str,
                        "downloaded": downloaded,
                        "total": total_size
                    }
                    print(f"[PROGRESS] {json.dumps(progress_msg)}", flush=True)

    async def download_file_with_progress(self, url: str, dest_path: str, package_name: str):
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._download_file_sync, url, dest_path, package_name)

    async def install_dependency(self, pkg: str, runtime: str) -> bool:
        vt_enabled = os.environ.get('VIRUSTOTAL_ENABLED', '0').strip() == '1'
        vt_api_key = os.environ.get('VIRUSTOTAL_API_KEY', '').strip()

        # Intercept and run pre-flight check
        check_res = ZeroTrustSandbox.run_preflight_check(pkg, runtime, vt_enabled, vt_api_key)
        if check_res["safety"] == "Blocked":
            raise SecurityAlertException(
                f"CRITICAL SECURITY BLOCK: Package '{pkg}' was blocked by Zero-Trust Smart Sandbox: {check_res['details']}"
            )
        elif check_res["safety"] == "Suspicious":
            raise SecurityAlertException(
                f"CRITICAL SECURITY BLOCK: Suspicious typosquatting/publish anomaly detected on '{pkg}' by Zero-Trust Smart Sandbox: {check_res['details']}"
            )

        use_offline = os.environ.get('UNDERHOOD_OFFLINE') == '1'
        cache_dir = os.path.join(os.path.expanduser("~"), ".underhood", "cache", runtime)
        os.makedirs(cache_dir, exist_ok=True)

        if runtime == 'python':
            if use_offline:
                cmd = [PYTHON_EXE, "-m", "pip", "install", pkg,
                       "-t", ".underhood_libs", "--no-index", "--find-links", cache_dir, "--no-user", "--isolated"]
            else:
                # Custom download with progress
                print(f"[PROGRESS] {json.dumps({'type': 'download_started', 'package': pkg})}", flush=True)
                url = self.fetch_pypi_whl_url(pkg)
                if url:
                    filename = url.split('/')[-1]
                    dest_path = os.path.join(cache_dir, filename)
                    try:
                        await self.download_file_with_progress(url, dest_path, pkg)
                        print(f"[PROGRESS] {json.dumps({'type': 'download_complete', 'package': pkg})}", flush=True)
                        cmd = [PYTHON_EXE, "-m", "pip", "install", dest_path,
                               "-t", ".underhood_libs", "--no-index", "--find-links", cache_dir, "--no-user", "--isolated"]
                    except Exception as e:
                        print(f"[PROGRESS] {json.dumps({'type': 'download_failed', 'package': pkg, 'error': str(e)})}", flush=True)
                        cmd = [PYTHON_EXE, "-m", "pip", "install", pkg,
                               "-t", ".underhood_libs", "--no-user", "--isolated"]
                else:
                    print(f"[PROGRESS] {json.dumps({'type': 'download_failed', 'package': pkg, 'error': 'Metadata resolution failed'})}", flush=True)
                    cmd = [PYTHON_EXE, "-m", "pip", "install", pkg,
                           "-t", ".underhood_libs", "--no-user", "--isolated"]

        elif runtime == 'node':
            if use_offline:
                cmd = ["npm", "install", pkg, "--cache", cache_dir, "--offline"]
            else:
                print(f"[PROGRESS] {json.dumps({'type': 'download_started', 'package': pkg})}", flush=True)
                url = self.fetch_npm_tarball_url(pkg)
                if url:
                    filename = url.split('/')[-1]
                    dest_path = os.path.join(cache_dir, filename)
                    try:
                        await self.download_file_with_progress(url, dest_path, pkg)
                        print(f"[PROGRESS] {json.dumps({'type': 'download_complete', 'package': pkg})}", flush=True)
                        cmd = ["npm", "install", dest_path, "--cache", cache_dir, "--prefer-offline"]
                    except Exception as e:
                        print(f"[PROGRESS] {json.dumps({'type': 'download_failed', 'package': pkg, 'error': str(e)})}", flush=True)
                        cmd = ["npm", "install", pkg, "--cache", cache_dir, "--prefer-offline"]
                else:
                    print(f"[PROGRESS] {json.dumps({'type': 'download_failed', 'package': pkg, 'error': 'Metadata resolution failed'})}", flush=True)
                    cmd = ["npm", "install", pkg, "--cache", cache_dir, "--prefer-offline"]

        elif runtime == 'lua':
            if use_offline:
                rock_file = None
                try:
                    for f in os.listdir(cache_dir):
                        if f.startswith(pkg) and f.endswith('.rock'):
                            rock_file = os.path.join(cache_dir, f)
                            break
                except Exception:
                    pass
                if rock_file:
                    cmd = ["luarocks", "install", rock_file, "--tree", "lua_modules", "--only-sources"]
                else:
                    cmd = ["luarocks", "install", pkg, "--tree", "lua_modules"]
            else:
                print(f"[PROGRESS] {json.dumps({'type': 'download_started', 'package': pkg})}", flush=True)
                download_cmd = ["luarocks", "download", pkg, "--dest", cache_dir]
                try:
                    proc_dl = await asyncio.create_subprocess_exec(
                        *download_cmd, cwd=self.directory,
                        stdout=asyncio.subprocess.DEVNULL,
                        stderr=asyncio.subprocess.DEVNULL
                    )
                    await proc_dl.communicate()
                    print(f"[PROGRESS] {json.dumps({'type': 'download_complete', 'package': pkg})}", flush=True)
                except Exception as e:
                    print(f"[PROGRESS] {json.dumps({'type': 'download_failed', 'package': pkg, 'error': str(e)})}", flush=True)
                cmd = ["luarocks", "install", pkg, "--tree", "lua_modules"]
        elif runtime == 'typescript':
            if shutil.which("bun"):
                cmd = ["bun", "add", pkg]
            else:
                cmd = ["npm", "install", pkg, "--save"]
        elif runtime == 'go':
            cmd = ["go", "get", pkg]
        elif runtime == 'rust':
            cmd = ["cargo", "add", pkg]
        elif runtime == 'dotnet':
            cmd = ["dotnet", "add", "package", pkg]
        elif runtime == 'ruby':
            cmd = ["gem", "install", pkg, "--install-dir", ".underhood_gems", "--no-document"]
        elif runtime == 'php':
            cmd = ["composer", "require", pkg, "--no-interaction"]
        elif runtime == 'powershell':
            pwsh_bin = "pwsh" if shutil.which("pwsh") else "powershell"
            cmd = [pwsh_bin, "-NoProfile", "-Command", f"Save-Module -Name '{pkg}' -Path '.underhood_psmodules' -Force"]
        else:
            return False

        process = await asyncio.create_subprocess_exec(
            *cmd, cwd=self.directory,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        await process.communicate()
        return process.returncode == 0

    def determine_runtime(self) -> str:
        d = self.directory
        if os.path.exists(os.path.join(d, 'tsconfig.json')) or os.path.exists(os.path.join(d, 'deno.json')) or os.path.exists(os.path.join(d, 'bunfig.toml')):
            return 'typescript'
        if os.path.exists(os.path.join(d, 'package.json')):
            try:
                with open(os.path.join(d, 'package.json'), 'r', encoding='utf-8') as pf:
                    pdata = json.load(pf)
                    deps = {**pdata.get('dependencies', {}), **pdata.get('devDependencies', {})}
                    if 'typescript' in deps:
                        return 'typescript'
            except Exception:
                pass
            return 'node'
        if os.path.exists(os.path.join(d, 'requirements.txt')) or os.path.exists(os.path.join(d, 'pyproject.toml')) or os.path.exists(os.path.join(d, 'setup.py')):
            return 'python'
        if os.path.exists(os.path.join(d, 'go.mod')):
            return 'go'
        if os.path.exists(os.path.join(d, 'Cargo.toml')):
            return 'rust'
        if os.path.exists(os.path.join(d, 'Gemfile')):
            return 'ruby'
        if os.path.exists(os.path.join(d, 'composer.json')):
            return 'php'
        try:
            files = os.listdir(d)
            if any(f.endswith('.rockspec') for f in files):
                return 'lua'
            if any(f.endswith('.csproj') or f.endswith('.sln') for f in files):
                return 'dotnet'
            if any(f.endswith(('.psd1', '.psm1')) for f in files):
                return 'powershell'
            for filename in files:
                filepath = os.path.join(d, filename)
                if os.path.isfile(filepath):
                    if filename.endswith(('.ts', '.tsx')):
                        return 'typescript'
                    if filename.endswith(('.js', '.mjs', '.cjs')):
                        return 'node'
                    if filename.endswith('.py'):
                        return 'python'
                    if filename.endswith('.lua'):
                        return 'lua'
                    if filename.endswith('.go'):
                        return 'go'
                    if filename.endswith('.rs'):
                        return 'rust'
                    if filename.endswith('.cs'):
                        return 'dotnet'
                    if filename.endswith('.rb'):
                        return 'ruby'
                    if filename.endswith('.php'):
                        return 'php'
                    if filename.endswith('.ps1'):
                        return 'powershell'
        except OSError:
            pass
        return 'python'


# ── RUNNABLE project types (Python / Node / Lua) ─────────────────────────────

RUNNABLE_TYPES = {
    "Python", "Node.js", "TypeScript", "Lua", "Go", "Rust",
    ".NET/C#", "Ruby", "PHP", "PowerShell"
}
ENTRY_SCRIPTS  = [
    "main.py", "app.py", "run.py", "start.py",
    "index.ts", "main.ts", "app.ts",
    "index.js", "app.js", "main.js",
    "main.lua", "init.lua",
    "main.go",
    "src/main.rs", "main.rs", "Cargo.toml",
    "Program.cs",
    "main.rb", "app.rb",
    "index.php", "main.php",
    "main.ps1", "run.ps1"
]


def _find_entry_script(directory: str) -> str | None:
    for name in ENTRY_SCRIPTS:
        p = os.path.join(directory, name)
        if os.path.isfile(p):
            return name
    return None


# ── CLI entry point (called by Rust via spawn_execution_loop) ─────────────────

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Usage: runner.py <project_folder_or_script> [--clean-sandbox | --clean-cache | --export-manifest]", file=sys.stderr)
        sys.exit(1)

    # CLI maintenance flags
    if "--clean-cache" in sys.argv:
        removed = clean_cache()
        print(json.dumps({"success": True, "files_removed": removed}), flush=True)
        sys.exit(0)

    target = sys.argv[1]
    if "--clean-sandbox" in sys.argv:
        cleaned = clean_sandbox(os.path.abspath(target))
        print(json.dumps({"success": True, "cleaned_folders": cleaned}), flush=True)
        sys.exit(0)

    if "--export-manifest" in sys.argv:
        r = UnderhoodRunner(os.path.abspath(target))
        runtime = r.determine_runtime()
        out_manifest = export_manifest(os.path.abspath(target), runtime)
        print(json.dumps({"success": True, "manifest_path": out_manifest}), flush=True)
        sys.exit(0)

    # Resolve to a directory
    if os.path.isfile(target):
        project_dir = os.path.dirname(os.path.abspath(target))
        script_name = os.path.basename(target)
    else:
        project_dir = os.path.abspath(target)
        script_name = None

    # ── Phase 0.5: Security hash scan (opt-in via env var) ──
    vt_scan = scan_security(project_dir)
    engine_name = vt_scan.get('engine', 'VirusTotal')
    if vt_scan.get("enabled"):
        if vt_scan.get("api_errors", 0) > 0:
            if engine_name == 'WindowsDefender':
                # Defender scan errors are non-fatal — log and continue analysis.
                # Common causes: needs elevation, service not running, etc.
                err = vt_scan.get("error_message") or "Windows Defender scan could not complete."
                print(f"[Zero-Trust Sandbox] WARNING: {err} Continuing analysis.", file=sys.stderr, flush=True)
                # Do NOT sys.exit — fall through to full analysis below
            else:
                # VirusTotal API errors ARE fatal (invalid key, rate limit, etc.)
                err = vt_scan.get("error_message") or "VirusTotal API error. Check your API key in settings."
                result = {
                    "project_type": "Unknown",
                    "can_run": False,
                    "executed": False,
                    "vt_scan": vt_scan,
                    "secrets_scan": scan_secrets(project_dir),
                    "blockers": [err],
                    "stdout": "",
                    "stderr": err,
                    "tools": [],
                    "dep_report": []
                }
                finalize_scan(result, project_dir)
                print(json.dumps(result), flush=True)
                sys.exit(1)
        elif len(vt_scan.get("malicious", [])) > 0:
            err = f"Malware detected in: {', '.join(vt_scan['malicious'])}"
            result = {
                "project_type": "Unknown",
                "can_run": False,
                "executed": False,
                "vt_scan": vt_scan,
                "secrets_scan": scan_secrets(project_dir),
                "blockers": [err],
                "stdout": "",
                "stderr": err,
                "tools": [],
                "dep_report": []
            }
            finalize_scan(result, project_dir)
            print(json.dumps(result), flush=True)
            sys.exit(1)

    # ── Phase 1: Universal project analysis ──────────────────────────────────
    analyzer = ProjectAnalyzer(project_dir)
    analysis = analyzer.analyze()
    result   = analysis.to_dict()
    result["vt_scan"] = vt_scan

    # ── Phase 1.5: Secrets & sensitive data scan (always runs, warn-only) ───────────────
    secrets_scan = scan_secrets(project_dir)
    result["secrets_scan"] = secrets_scan
    if secrets_scan.get('counts', {}).get('CRITICAL', 0) > 0:
        high_count = secrets_scan['counts']['CRITICAL']
        print(f"[Secrets Scanner] WARNING: {high_count} CRITICAL secret(s) found. Review and rotate exposed credentials.",
              file=sys.stderr, flush=True)

    # ── Phase 2: Execute (only for Python/Node/Lua with an entry script) ─────
    if result.get("can_run", False) and analysis.project_type in RUNNABLE_TYPES:
        entry = script_name or _find_entry_script(analysis.directory)
        if entry:
            runner = UnderhoodRunner(directory=analysis.directory)
            exec_result = asyncio.run(runner.run_with_repair(entry))
            # Merge execution results into the analysis result
            result["returncode"] = exec_result.get("returncode", 0)
            result["stdout"]     = exec_result.get("stdout", "")
            result["stderr"]     = exec_result.get("stderr", "") if not result.get("stderr") else f"{result['stderr']}\n{exec_result.get('stderr', '')}"
            result["dep_report"] = exec_result.get("dep_report", [])
            result["executed"]   = True
        else:
            result["executed"] = False
            result["notes"] = result.get("notes", []) + [
                "No entry script found (main.py / index.js). "
                "Analysis complete but project was not executed."
            ]
    else:
        result["executed"] = False

    finalize_scan(result, project_dir)
    print(json.dumps(result), flush=True)
    sys.exit(0 if result.get("can_run", False) else 1)
